import fs from 'fs';
import path from 'path';

export type CampusType = 'Darusslam Campus' | 'Lucknow Campus' | 'Zaman Town Campus';

export interface DiaryEntry {
  id: string;
  date: string; // YYYY-MM-DD
  grade: string; // e.g. "Class 5", "Class 9", "Pre-Primary"
  section?: string; // "A", "B", "Rose"
  subject: string; // "Mathematics", "English", "Urdu", "Science", etc.
  campus: string; // "Darusslam Campus" | "Lucknow Campus" | "Zaman Town Campus"
  teacherName: string;
  teacherDesignation?: string;
  teacherPhone: string;
  title: string;
  homeworkText: string;
  imageUrl?: string; // Base64 or image link
  createdAt: string; // ISO
}

export interface TeacherUser {
  id: string;
  name: string;
  phone: string;
  pin: string; // Unique 4-digit PIN per teacher
  password: string; // Master/Secret password (default 'teacher@creek123')
  designation?: string; // e.g. "Senior Faculty", "Mathematics Specialist"
  campus?: string; // Default or assigned campus
  subjects: string[];
  assignedGrades: string[];
  registeredAt?: string;
}

export interface DatabaseSchema {
  teachers: TeacherUser[];
  diaries: DiaryEntry[];
  lastPurgedAt: string;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'school_database.json');

// Helper to format date YYYY-MM-DD
export function getLocalDateString(offsetDays = 0): string {
  const d = new Date();
  d.setDate(d.getDate() - offsetDays);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Generate realistic initial data
function getDefaultDatabase(): DatabaseSchema {
  const todayStr = getLocalDateString(0);
  const yesterdayStr = getLocalDateString(1);
  const dayBeforeStr = getLocalDateString(2);

  const defaultTeachers: TeacherUser[] = [
    {
      id: 't-1',
      name: 'Sir Hassam',
      designation: 'Admin & Senior Faculty',
      campus: 'Darusslam Campus',
      phone: '03126172674',
      pin: '4826',
      password: 'teacher@creek123',
      subjects: ['Mathematics', 'Physics', 'Computer Science'],
      assignedGrades: ['Class 9', 'Class 10', 'Class 8'],
      registeredAt: new Date().toISOString(),
    },
    {
      id: 't-2',
      name: 'Miss Ayesha Khan',
      designation: 'Primary & Middle Wing Incharge',
      campus: 'Lucknow Campus',
      phone: '03001234567',
      pin: '5914',
      password: 'teacher@creek123',
      subjects: ['English', 'Urdu', 'Social Studies'],
      assignedGrades: ['Class 5', 'Class 6', 'Class 7'],
      registeredAt: new Date().toISOString(),
    },
    {
      id: 't-3',
      name: 'Sir Tariq Mahmood',
      designation: 'Science Faculty Head',
      campus: 'Zaman Town Campus',
      phone: '03339876543',
      pin: '3170',
      password: 'teacher@creek123',
      subjects: ['Science', 'General Knowledge', 'Islamiat'],
      assignedGrades: ['Class 1 - 5', 'Pre-Primary', 'Class 3'],
      registeredAt: new Date().toISOString(),
    },
  ];

  const defaultDiaries: DiaryEntry[] = [
    {
      id: 'diary-today-1',
      date: todayStr,
      grade: 'Class 9',
      section: 'A',
      subject: 'Mathematics',
      campus: 'Darusslam Campus',
      teacherName: 'Sir Hassam',
      teacherDesignation: 'Admin & Senior Faculty',
      teacherPhone: '03126172674',
      title: 'Chapter 4: Algebraic Expressions Exercise 4.2',
      homeworkText: 'Complete Q.No 5 to 8 from Exercise 4.2 in neat homework register. Formulas for (a+b)³ and (a-b)³ will be tested tomorrow on the board.',
      imageUrl: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?q=80&w=800',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'diary-today-2',
      date: todayStr,
      grade: 'Class 5',
      section: 'Rose',
      subject: 'English',
      campus: 'Lucknow Campus',
      teacherName: 'Miss Ayesha Khan',
      teacherDesignation: 'Primary & Middle Wing Incharge',
      teacherPhone: '03001234567',
      title: 'Unit 7: The Brave Little Kite - Reading & Vocabulary',
      homeworkText: 'Learn meanings of 5 new words from page 48. Write 5 sentences using each new word. Dictation test tomorrow morning.',
      imageUrl: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?q=80&w=800',
      createdAt: new Date(Date.now() - 3600000).toISOString(),
    },
    {
      id: 'diary-yesterday-1',
      date: yesterdayStr,
      grade: 'Class 10',
      section: 'B',
      subject: 'Physics',
      campus: 'Darusslam Campus',
      teacherName: 'Sir Hassam',
      teacherDesignation: 'Admin & Senior Faculty',
      teacherPhone: '03126172674',
      title: 'Unit 12: Geometrical Optics Numerical Problems',
      homeworkText: 'Solve numerical problems 12.1 and 12.4 using mirror formula 1/f = 1/p + 1/q. Bring scientific calculator.',
      imageUrl: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?q=80&w=800',
      createdAt: new Date(Date.now() - 86400000).toISOString(),
    },
    {
      id: 'diary-yesterday-2',
      date: yesterdayStr,
      grade: 'Pre-Primary',
      section: 'Nursery',
      subject: 'General Knowledge & Rhymes',
      campus: 'Zaman Town Campus',
      teacherName: 'Sir Tariq Mahmood',
      teacherDesignation: 'Science Faculty Head',
      teacherPhone: '03339876543',
      title: 'Shapes Identification & Coloring Activity',
      homeworkText: 'Identify Circle and Square from workbook page 12. Color the balloons in red color. Bring craft paper tomorrow.',
      imageUrl: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=800',
      createdAt: new Date(Date.now() - 90000000).toISOString(),
    },
    {
      id: 'diary-day2-1',
      date: dayBeforeStr,
      grade: 'Class 8',
      section: 'A',
      subject: 'Urdu',
      campus: 'Lucknow Campus',
      teacherName: 'Miss Ayesha Khan',
      teacherDesignation: 'Primary & Middle Wing Incharge',
      teacherPhone: '03001234567',
      title: 'Sabaq: Hamd - Tashreeh & Khulasa',
      homeworkText: 'Hamd k aakhri 3 ashaar ki tashreeh khush-khat copy mein tehreer karein aur alfaaz maani yaad karein.',
      imageUrl: 'https://images.unsplash.com/photo-1588075592446-265fd1e6e76f?q=80&w=800',
      createdAt: new Date(Date.now() - 172800000).toISOString(),
    },
    {
      id: 'diary-day2-2',
      date: dayBeforeStr,
      grade: 'Class 6',
      section: 'Tulip',
      subject: 'Science',
      campus: 'Zaman Town Campus',
      teacherName: 'Sir Tariq Mahmood',
      teacherDesignation: 'Science Faculty Head',
      teacherPhone: '03339876543',
      title: 'Living Organisms: Plant and Animal Cells',
      homeworkText: 'Draw neat labeled diagram of a Plant Cell on science register page 34.',
      imageUrl: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?q=80&w=800',
      createdAt: new Date(Date.now() - 180000000).toISOString(),
    },
  ];

  return {
    teachers: defaultTeachers,
    diaries: defaultDiaries,
    lastPurgedAt: new Date().toISOString(),
  };
}

// Ensure database file exists
function ensureDb(): DatabaseSchema {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (!fs.existsSync(DB_FILE)) {
    const initialData = getDefaultDatabase();
    fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), 'utf-8');
    return initialData;
  }

  try {
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    const data = JSON.parse(raw);
    let changed = false;

    if (!data.teachers || !Array.isArray(data.teachers) || data.teachers.length === 0) {
      data.teachers = getDefaultDatabase().teachers;
      changed = true;
    }
    if (!data.diaries || !Array.isArray(data.diaries) || data.diaries.length === 0) {
      data.diaries = getDefaultDatabase().diaries;
      changed = true;
    } else {
      // Ensure each existing diary has a campus assigned
      const defaultCampuses = ['Darusslam Campus', 'Lucknow Campus', 'Zaman Town Campus'];
      data.diaries.forEach((d: DiaryEntry, idx: number) => {
        if (!d.campus) {
          d.campus = defaultCampuses[idx % 3];
          changed = true;
        } else if (d.campus.includes('Society')) {
          d.campus = d.campus.replace(' Society', '');
          changed = true;
        }
      });
    }

    if (changed) {
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    }
    return data;
  } catch (err) {
    console.error('Error reading school database file, restoring defaults:', err);
    const initialData = getDefaultDatabase();
    fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2), 'utf-8');
    return initialData;
  }
}

export function getDatabase(): DatabaseSchema {
  return ensureDb();
}

export function saveDatabase(data: DatabaseSchema): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (error) {
    console.error('Error saving school database:', error);
  }
}

/**
 * 3-Day Rule:
 * Calculates valid dates: today, yesterday, and 2 days ago.
 * Purges anything older than 3 days automatically.
 */
export function purgeOldDiaries(): { purgedCount: number; remainingCount: number } {
  const db = getDatabase();
  const validDates = new Set([
    getLocalDateString(0),
    getLocalDateString(1),
    getLocalDateString(2),
  ]);

  const initialCount = db.diaries.length;
  db.diaries = db.diaries.filter((item) => validDates.has(item.date));
  const purgedCount = initialCount - db.diaries.length;

  db.lastPurgedAt = new Date().toISOString();
  saveDatabase(db);

  return {
    purgedCount,
    remainingCount: db.diaries.length,
  };
}

export function getDiaryEntries(): DiaryEntry[] {
  // Purge expired entries whenever diaries are requested
  purgeOldDiaries();
  const db = getDatabase();
  return db.diaries.sort((a, b) => {
    if (a.date !== b.date) {
      return b.date.localeCompare(a.date);
    }
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });
}

export function addDiaryEntry(entry: Omit<DiaryEntry, 'id' | 'createdAt'>): DiaryEntry {
  const db = getDatabase();
  const newEntry: DiaryEntry = {
    ...entry,
    campus: entry.campus || 'Darusslam Campus',
    id: 'diary-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    createdAt: new Date().toISOString(),
  };

  db.diaries.unshift(newEntry);
  saveDatabase(db);
  return newEntry;
}

export function deleteDiaryEntry(id: string): boolean {
  const db = getDatabase();
  const initialCount = db.diaries.length;
  db.diaries = db.diaries.filter((d) => d.id !== id);
  if (db.diaries.length !== initialCount) {
    saveDatabase(db);
    return true;
  }
  return false;
}

export function findTeacherByPhone(phone: string): TeacherUser | undefined {
  const db = getDatabase();
  const cleaned = phone.replace(/[\s\-\+]/g, '');
  return db.teachers.find((t) => t.phone.replace(/[\s\-\+]/g, '') === cleaned);
}

export function saveTeacher(teacher: TeacherUser): void {
  const db = getDatabase();
  const cleaned = teacher.phone.replace(/[\s\-\+]/g, '');
  teacher.phone = cleaned;

  const idx = db.teachers.findIndex((t) => t.phone.replace(/[\s\-\+]/g, '') === cleaned);
  if (idx >= 0) {
    db.teachers[idx] = {
      ...db.teachers[idx],
      ...teacher,
    };
  } else {
    db.teachers.push(teacher);
  }
  saveDatabase(db);
}

// Update teacher profile (name, designation, campus, subjects) permanently
export function updateTeacherProfile(
  phone: string,
  updates: { name?: string; designation?: string; campus?: string; subjects?: string[] }
): TeacherUser | null {
  const db = getDatabase();
  const cleaned = phone.replace(/[\s\-\+]/g, '');
  const teacher = db.teachers.find((t) => t.phone.replace(/[\s\-\+]/g, '') === cleaned);

  if (!teacher) return null;

  if (updates.name && updates.name.trim()) {
    teacher.name = updates.name.trim();
  }
  if (updates.designation !== undefined) {
    teacher.designation = updates.designation.trim();
  }
  if (updates.campus && updates.campus.trim()) {
    teacher.campus = updates.campus.trim();
  }
  if (updates.subjects && Array.isArray(updates.subjects)) {
    teacher.subjects = updates.subjects;
  }

  saveDatabase(db);
  return teacher;
}
