'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  Menu,
  X,
  Phone,
  Mail,
  Calendar,
  Lock,
  GraduationCap,
  Sparkles,
  ChevronRight,
  UserCheck
} from 'lucide-react';

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isTeacherLoggedIn, setIsTeacherLoggedIn] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  // Clean navLinks without campus page or campus name
  const navLinks = [
    { name: 'HOME', href: '/' },
    { name: 'ABOUT US', href: '/about' },
    { name: 'ACADEMICS', href: '/academics' },
    { name: 'DAILY DIARY', href: '/diary', badge: 'Active 3-Day' },
    { name: 'BLOG & NEWS', href: '/blog' },
    { name: 'CONTACT US', href: '/contact' },
  ];

  // Check 1-time teacher session on mount
  useEffect(() => {
    const timer = setTimeout(() => {
      if (typeof window !== 'undefined') {
        const token = localStorage.getItem('creek_teacher_token');
        const data = localStorage.getItem('creek_teacher_data');
        if (token && data) {
          setIsTeacherLoggedIn(true);
        } else {
          setIsTeacherLoggedIn(false);
        }
      }
    }, 0);
    return () => clearTimeout(timer);
  }, [pathname]);

  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  };

  // Direct Teacher Portal navigation: 1-click to dashboard if logged in, otherwise login page
  const handleTeacherPortalClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('creek_teacher_token');
      const data = localStorage.getItem('creek_teacher_data');
      if (token && data) {
        router.push('/teacher/dashboard');
        return;
      }
    }
    router.push('/teacher/login');
  };

  return (
    <>
      {/* Top Header Information Bar - Always accessible across all devices */}
      <div className="bg-[#6e0000] text-white text-xs py-2 px-3 sm:px-4 border-b border-red-900/40">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          {/* Left: Contact Info (No campus names) */}
          <div className="flex items-center space-x-4 sm:space-x-6 text-[11px] sm:text-xs">
            <a
              href="tel:+923126172674"
              className="flex items-center gap-1.5 text-white/90 hover:text-white transition font-medium"
            >
              <Phone className="w-3.5 h-3.5 text-red-300" />
              <span>+92 312 6172674</span>
            </a>
            <span className="hidden md:flex items-center gap-1.5 text-white/90 font-medium">
              <Mail className="w-3.5 h-3.5 text-red-300" />
              <span>info@creekviewacademy.edu.pk</span>
            </span>
          </div>

          {/* Right: Roznamcha & Fully Functional Teacher Portal Button */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            <Link
              href="/diary"
              className="flex items-center gap-1 text-red-200 hover:text-white font-semibold bg-red-900/60 hover:bg-red-900 px-2.5 py-1 rounded-full text-[11px] transition border border-red-700/50"
            >
              <Calendar className="w-3 h-3 text-red-300" />
              <span>Roznamcha / Student Diary</span>
            </Link>

            {/* Header Teacher Login / Portal Button */}
            <button
              onClick={handleTeacherPortalClick}
              type="button"
              className="flex items-center gap-1.5 text-white font-extrabold bg-gradient-to-r from-red-800 to-[#8B0000] hover:from-red-700 hover:to-red-800 px-3 py-1 rounded-full transition text-[11px] shadow-sm border border-red-400/40 cursor-pointer active:scale-95"
            >
              {isTeacherLoggedIn ? (
                <>
                  <UserCheck className="w-3.5 h-3.5 text-yellow-300" />
                  <span>Teacher Portal (Direct Upload)</span>
                </>
              ) : (
                <>
                  <Lock className="w-3 h-3 text-yellow-300" />
                  <span>Teacher Login</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Main Sticky Navbar with User's Signature Red Rounded Pill */}
      <header className="shadow-md sticky top-0 z-50 bg-white/95 backdrop-blur-md transition-all">
        <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2 sm:py-2.5">
          <div className="bg-[#8B0000] shadow-xl text-white rounded-full px-4 sm:px-6 h-18 sm:h-20 flex items-center justify-between border-2 border-red-800/40">
            {/* School Logo & Title */}
            <Link href="/" className="flex items-center space-x-3 group">
              <div className="w-12 h-12 sm:w-14 sm:h-14 bg-white rounded-full p-1 shadow-md flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                <img
                  src="/assets/logo.png"
                  alt="Creek View Academy Logo"
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://amazing-smakager-c23372.netlify.app/assets/logo.png';
                  }}
                />
              </div>
              <div className="leading-tight">
                <h1 className="font-extrabold text-lg sm:text-xl tracking-tight text-white uppercase drop-shadow-sm">
                  Creek View
                </h1>
                <p className="text-xs sm:text-sm font-semibold tracking-wider text-red-100 uppercase">
                  Academy
                </p>
              </div>
            </Link>

            {/* Desktop Navigation Links (NO Campus links) */}
            <nav className="hidden lg:flex items-center space-x-1 xl:space-x-3 text-sm font-bold tracking-wide">
              {navLinks.map((link) => {
                const active = isActive(link.href);
                return (
                  <Link
                    key={link.name}
                    href={link.href}
                    className={`relative px-3 py-2 rounded-lg transition-all flex items-center gap-1 ${
                      active
                        ? 'bg-white/20 text-white font-extrabold shadow-inner'
                        : 'text-white/90 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <span>{link.name}</span>
                    {link.badge && (
                      <span className="text-[10px] bg-yellow-400 text-red-900 font-extrabold px-1.5 py-0.2 rounded-full uppercase tracking-tighter ml-0.5">
                        {link.badge}
                      </span>
                    )}
                  </Link>
                );
              })}
            </nav>

            {/* Action Buttons & Mobile Toggle (Teacher login removed from navbar pill as requested) */}
            <div className="flex items-center space-x-2 sm:space-x-3">
              <Link
                href="/admissions"
                className="bg-white text-[#8B0000] hover:bg-red-50 hover:shadow-lg font-extrabold text-xs sm:text-sm px-4 sm:px-5 py-2.5 rounded-full transition-all transform active:scale-95 shadow-md flex items-center gap-1.5"
              >
                <GraduationCap className="w-4 h-4 hidden sm:inline" />
                <span>ADMISSIONS</span>
              </Link>

              {/* Mobile Menu Hamburger */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden text-white p-2 rounded-lg hover:bg-white/10 transition"
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#8B0000] mx-4 my-2 rounded-2xl p-5 shadow-2xl border border-red-700 animate-fadeIn text-white">
            <div className="flex flex-col space-y-1">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-semibold transition ${
                    isActive(link.href) ? 'bg-white/20 text-white font-bold' : 'hover:bg-white/10'
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <ChevronRight className="w-4 h-4 text-red-300" />
                    {link.name}
                  </span>
                  {link.badge && (
                    <span className="text-[10px] bg-yellow-400 text-red-900 font-extrabold px-2 py-0.5 rounded-full">
                      {link.badge}
                    </span>
                  )}
                </Link>
              ))}

              <div className="pt-3 mt-2 border-t border-red-700/60 flex flex-col gap-2">
                <button
                  onClick={(e) => {
                    setMobileMenuOpen(false);
                    handleTeacherPortalClick(e);
                  }}
                  className="bg-red-950/80 hover:bg-red-950 text-white text-center py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 border border-red-700/50 w-full"
                >
                  <Lock className="w-4 h-4 text-yellow-300" />
                  <span>{isTeacherLoggedIn ? 'Teacher Portal (Direct Upload)' : 'Teacher Portal Login'}</span>
                </button>
                <Link
                  href="/admissions"
                  onClick={() => setMobileMenuOpen(false)}
                  className="bg-white text-[#8B0000] text-center py-2.5 rounded-xl font-extrabold text-sm shadow-md"
                >
                  Online Admission Form 2026-27
                </Link>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
}
