'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import {
  MapPin,
  Phone,
  Mail,
  ArrowRight,
  CheckCircle,
  Facebook,
  Instagram,
  Youtube,
  Linkedin,
  Clock,
  Sparkles
} from 'lucide-react';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  return (
    <footer className="bg-[#8B0000] text-white border-t-4 border-red-900 mt-auto">
      {/* Upper Footer CTA Strip */}
      <div className="bg-[#680000] py-6 px-4 border-b border-white/10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
          <div>
            <h3 className="text-xl sm:text-2xl font-black text-white tracking-wide">
              Admissions Open for Session 2026-27!
            </h3>
            <p className="text-white/80 text-sm mt-0.5">
              Secure your child&apos;s future at Creek View Academy. Quality education with modern facilities.
            </p>
          </div>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link
              href="/admissions"
              className="bg-white text-[#8B0000] hover:bg-red-50 font-extrabold px-6 py-2.5 rounded-full text-sm shadow-lg transition transform hover:-translate-y-0.5"
            >
              Apply Online Now
            </Link>
            <a
              href="https://wa.me/923126172674?text=Hello%20Creek%20View%20Academy%2C%20I%20would%20like%20to%20inquire%20about%20admissions"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-2.5 rounded-full text-sm shadow-lg transition flex items-center gap-1.5"
            >
              WhatsApp Us
            </a>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10">
          {/* 1. School Logo & Bio */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 bg-white rounded-full p-1.5 shadow-lg flex items-center justify-center shrink-0">
                <img
                  src="/assets/logo.png"
                  alt="Creek View Academy"
                  className="w-full h-full object-contain"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://amazing-smakager-c23372.netlify.app/assets/logo.png';
                  }}
                />
              </div>
              <div>
                <h3 className="text-2xl font-black tracking-tight leading-none text-white">CREEK VIEW</h3>
                <p className="text-xl font-bold tracking-wider text-red-200">ACADEMY</p>
                <span className="text-[11px] uppercase tracking-widest text-white/70">Karachi, Pakistan</span>
              </div>
            </div>

            <p className="text-sm text-white/85 leading-relaxed">
              Nurturing minds. Shaping futures. A premier educational institution offering holistic schooling from Pre-Primary to Matriculation across multiple campuses in Karachi.
            </p>

            {/* Social Links */}
            <div className="pt-2">
              <p className="text-xs font-bold uppercase tracking-wider text-red-200 mb-2.5">Follow Our Activities</p>
              <div className="flex gap-2.5">
                <a
                  href="https://www.facebook.com/creekviewa/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white hover:text-[#8B0000] transition"
                  aria-label="Facebook"
                >
                  <Facebook className="w-5 h-5" />
                </a>
                <a
                  href="https://www.instagram.com/popular/creek-view-karachi/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white hover:text-[#8B0000] transition"
                  aria-label="Instagram"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a
                  href="https://www.youtube.com/watch?v=LNSZEZ0CSDk"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white hover:text-[#8B0000] transition"
                  aria-label="YouTube"
                >
                  <Youtube className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          {/* 2. Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-extrabold text-sm uppercase tracking-wider text-white border-b border-white/20 pb-2">
              Quick Links
            </h4>
            <ul className="space-y-2 text-sm text-white/85">
              <li>
                <Link href="/" className="hover:text-white hover:translate-x-1 inline-block transition">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-white hover:translate-x-1 inline-block transition">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/academics" className="hover:text-white hover:translate-x-1 inline-block transition">
                  Academics & Wings
                </Link>
              </li>
              <li>
                <Link href="/diary" className="hover:text-white hover:translate-x-1 inline-block transition font-semibold text-yellow-300">
                  Daily School Diary
                </Link>
              </li>
              <li>
                <Link href="/blog" className="hover:text-white hover:translate-x-1 inline-block transition">
                  School Blog & News
                </Link>
              </li>
              <li>
                <Link href="/admissions" className="hover:text-white hover:translate-x-1 inline-block transition">
                  Admission Process
                </Link>
              </li>
              <li>
                <Link href="/teacher/login" className="hover:text-white hover:translate-x-1 inline-block transition text-red-200">
                  Teacher Login
                </Link>
              </li>
            </ul>
          </div>

          {/* 3. Campuses in Karachi */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-extrabold text-sm uppercase tracking-wider text-white border-b border-white/20 pb-2">
              Our 3 Campuses
            </h4>
            <div className="space-y-3 text-xs text-white/85">
              <div className="bg-white/5 p-2.5 rounded-lg border border-white/10 hover:bg-white/10 transition">
                <p className="font-bold text-white text-sm">1. Drusslum Society Campus</p>
                <p className="text-white/70 mt-0.5">Opp. Fazal-e-Elahi Hospital, Drusslum Society, Karachi</p>
                <a
                  href="https://maps.google.com/?q=Drusslum+Society+Fazal+E+Elahi+Hospital+Karachi"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-yellow-300 hover:underline inline-flex items-center gap-1 mt-1 font-semibold"
                >
                  Map Location →
                </a>
              </div>

              <div className="bg-white/5 p-2.5 rounded-lg border border-white/10 hover:bg-white/10 transition">
                <p className="font-bold text-white text-sm">2. Lucknow Society Campus</p>
                <p className="text-white/70 mt-0.5">Shaq al Mandi Street, Lucknow Society, Karachi</p>
                <a
                  href="https://maps.google.com/?q=Lucknow+Society+Shaq+al+Mandi+Street+Karachi"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-yellow-300 hover:underline inline-flex items-center gap-1 mt-1 font-semibold"
                >
                  Map Location →
                </a>
              </div>

              <div className="bg-white/5 p-2.5 rounded-lg border border-white/10 hover:bg-white/10 transition">
                <p className="font-bold text-white text-sm">3. Zaman Town Campus</p>
                <p className="text-white/70 mt-0.5">Zaman Town, Korangi, Karachi</p>
                <a
                  href="https://maps.google.com/?q=Zaman+Town+Karachi"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-yellow-300 hover:underline inline-flex items-center gap-1 mt-1 font-semibold"
                >
                  Map Location →
                </a>
              </div>
            </div>
          </div>

          {/* 4. Contact & Newsletter */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="font-extrabold text-sm uppercase tracking-wider text-white border-b border-white/20 pb-2">
              Get In Touch
            </h4>
            <ul className="space-y-2.5 text-xs text-white/85">
              <li className="flex items-start gap-2.5">
                <Phone className="w-4 h-4 text-red-200 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold block text-white">Call / WhatsApp:</span>
                  <a href="tel:+923126172674" className="hover:text-white underline">
                    +92 312 6172674
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-red-200 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold block text-white">Email Address:</span>
                  <a href="mailto:info@creekviewacademy.edu.pk" className="hover:text-white">
                    info@creekviewacademy.edu.pk
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-red-200 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold block text-white">School Office Hours:</span>
                  <span>Monday - Saturday: 8:00 AM - 2:00 PM</span>
                </div>
              </li>
            </ul>

            {/* Newsletter */}
            <div className="pt-2">
              <p className="text-xs font-bold uppercase tracking-wider text-white mb-2">School Bulletin</p>
              {subscribed ? (
                <div className="bg-white/20 text-white text-xs p-2.5 rounded-lg flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-yellow-300" />
                  <span>Subscribed! Thank you for staying connected.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter email for alerts"
                    required
                    className="w-full px-3 py-2 text-xs rounded-l-lg text-gray-900 bg-white placeholder-gray-500 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="bg-red-950 hover:bg-black text-white px-3 py-2 rounded-r-lg text-xs font-bold flex items-center transition"
                    aria-label="Subscribe"
                  >
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/20 bg-[#680000]">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row justify-between items-center text-xs text-white/75 gap-2">
          <p>© {new Date().getFullYear()} Creek View Academy Karachi. All Rights Reserved.</p>
          <div className="flex items-center space-x-4">
            <Link href="/admissions" className="hover:text-white">Admissions Policy</Link>
            <span>•</span>
            <Link href="/diary" className="hover:text-white">3-Day Diary Retention Policy</Link>
            <span>•</span>
            <Link href="/contact" className="hover:text-white">Help & Support</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
