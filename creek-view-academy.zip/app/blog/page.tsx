'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import BackToTop from '@/components/BackToTop';
import {
  Calendar,
  User,
  Clock,
  ArrowRight,
  Search,
  Tag,
  BookOpen,
  Share2,
  X,
  MessageCircle,
  ThumbsUp,
  Sparkles,
  ChevronRight
} from 'lucide-react';

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string[];
  category: 'Campus News' | 'Academic Excellence' | 'Sports & Events' | 'Parenting & Study Tips';
  author: string;
  role: string;
  date: string;
  readTime: string;
  imageUrl: string;
  tags: string[];
}

const blogPosts: BlogPost[] = [
  {
    id: 'post-1',
    title: 'Creek View Academy Celebrates 100% First Division in Board Examinations',
    excerpt: 'Our Matriculation batch achieves record-breaking results with top positions across Karachi board, highlighting academic dedication and quality mentoring.',
    content: [
      'We are thrilled to announce that Creek View Academy students have once again demonstrated exceptional academic prowess in the Board of Secondary Education Karachi (BSEK) examinations.',
      'Over 90% of our registered candidates secured A-one and A grades in Science and Computer groups. This remarkable achievement reflects our focused curriculum, rigorous mock assessments, and personalized after-school remedial sessions.',
      'Our Principal, in an address to faculty and parents, commended the relentless dedication of teachers and parents who stood firmly beside every student throughout the preparation period.',
      'Special certificates of distinction and scholarships will be awarded to top scorers at the upcoming Annual Prize Distribution Ceremony.'
    ],
    category: 'Academic Excellence',
    author: 'Academic Directorate',
    role: 'Board Examination Wing',
    date: 'October 8, 2026',
    readTime: '4 min read',
    imageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=800',
    tags: ['Matriculation', 'BSEK', 'Achievements', 'Results'],
  },
  {
    id: 'post-2',
    title: 'Annual Science & Robotics Exhibition Held at Zaman Town Campus',
    excerpt: 'Students from Class 5 through 10 exhibited cutting-edge automated prototypes, renewable energy solutions, and biomedical innovations.',
    content: [
      'The multi-purpose auditorium at our Zaman Town Campus transformed into a vibrant hub of young scientists, engineers, and researchers during the Annual STEM Exhibition.',
      'Highlights included an automated solar tracking irrigation model developed by Class 9 students, an AI voice-assisted educational assistant, and hands-on chemistry reaction demonstrations.',
      'Distinguished professors from NED University and Karachi University served as guest evaluators, praising the conceptual clarity and presentation poise of our pupils.',
      'At Creek View Academy, our science laboratories are continuously upgraded to ensure theoretical learning is reinforced with hands-on discovery.'
    ],
    category: 'Campus News',
    author: 'Faculty of Science',
    role: 'STEM Coordinators',
    date: 'October 4, 2026',
    readTime: '3 min read',
    imageUrl: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?q=80&w=800',
    tags: ['Science', 'Robotics', 'Innovation', 'STEM'],
  },
  {
    id: 'post-3',
    title: '5 Practical Tips for Parents to Support Children with Daily Homework & Revision',
    excerpt: 'How creating structured routines, reviewing the 3-day school diary, and encouraging independent inquiry boost academic success at home.',
    content: [
      'Parental engagement is the cornerstone of student confidence. However, helping children with homework does not mean doing the work for them; it means creating the ideal environment for independent learning.',
      '1. Utilize the Online School Diary Daily: Check your child’s Roznamcha on our website each evening to verify assigned tasks and test schedules.',
      '2. Establish a Dedicated Study Zone: Eliminate digital distractions, television screens, and loud noises during focused 45-minute study intervals.',
      '3. Encourage Curiosity: When your child struggles with a question, ask guiding questions rather than providing immediate answers.',
      '4. Maintain Open Communication with Teachers: Use parent-teacher meetings and teacher helpline hours to stay aligned on learning targets.'
    ],
    category: 'Parenting & Study Tips',
    author: 'Child Psychology Department',
    role: 'Student Counselor',
    date: 'September 28, 2026',
    readTime: '5 min read',
    imageUrl: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=800',
    tags: ['Parenting', 'Study Habits', 'Homework', 'Guidance'],
  },
  {
    id: 'post-4',
    title: 'Inter-Campus Sports Gala 2026: Team Spirit and Athleticism Shine',
    excerpt: 'Over 400 athletes from Drusslum Society, Lucknow Society, and Zaman Town campuses competed in cricket, badminton, athletics, and football.',
    content: [
      'The spirit of sportsmanship was on full display as the annual Inter-Campus Sports Gala brought together pupils, educators, and alumni.',
      'Competitions spanned 100m sprint heats, cricket tournaments, relay races, and chess championships.',
      'The coveted Champion Trophy of 2026 was lifted by the Zaman Town campus contingent after a thrilling cricket final decided on the last over!',
      'Physical education and sports are an indispensable component of the holistic curriculum at Creek View Academy, building grit, discipline, and teamwork.'
    ],
    category: 'Sports & Events',
    author: 'Sports Committee',
    role: 'Physical Education Department',
    date: 'September 20, 2026',
    readTime: '4 min read',
    imageUrl: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?q=80&w=800',
    tags: ['Sports', 'Cricket', 'Athletics', 'Gala'],
  },
  {
    id: 'post-5',
    title: 'Smart Classrooms & Digital Whiteboard Facilities Introduced Across All Wings',
    excerpt: 'Interactive multimedia screens, digital libraries, and audio-visual instructional aids enhance interactive classroom engagement.',
    content: [
      'In our continuing commitment to modern education, Creek View Academy has equipped every secondary classroom across all three campuses with high-definition digital smart boards.',
      'Teachers now seamlessly integrate animated scientific models, interactive mathematical graphing, and geographical maps into everyday lectures.',
      'Students retain complex topics faster through multi-sensory stimulation, making education joyful and deeply memorable.'
    ],
    category: 'Campus News',
    author: 'Administration',
    role: 'IT Directorate',
    date: 'September 12, 2026',
    readTime: '3 min read',
    imageUrl: 'https://images.unsplash.com/photo-1588075592446-265fd1e6e76f?q=80&w=800',
    tags: ['Smart Classrooms', 'Technology', 'Digital Campus'],
  },
  {
    id: 'post-6',
    title: 'Early Childhood Education: Why the Montessori Method Matters',
    excerpt: 'Discover how hands-on sensory learning and phonics-based language exploration lay the ultimate foundation in Nursery and Kindergarten.',
    content: [
      'The early developmental years between ages 3 and 6 represent a child’s most critical period of neural development and cognitive curiosity.',
      'At Creek View Academy’s Pre-Primary Wing, our curriculum is rooted in internationally recognized Montessori principles paired with values-based social education.',
      'Through tactile manipulative blocks, rhyme immersion, and safe indoor activity zones, little learners build strong fine motor skills and joyful confidence.'
    ],
    category: 'Parenting & Study Tips',
    author: 'Montessori Wing Head',
    role: 'Early Years Coordinator',
    date: 'September 5, 2026',
    readTime: '4 min read',
    imageUrl: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?q=80&w=800',
    tags: ['Early Years', 'Montessori', 'Pre-Primary', 'Phonics'],
  },
];

export default function BlogPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [activePost, setActivePost] = useState<BlogPost | null>(null);

  const categories = [
    'ALL',
    'Campus News',
    'Academic Excellence',
    'Sports & Events',
    'Parenting & Study Tips',
  ];

  const filteredPosts = blogPosts.filter((post) => {
    if (selectedCategory !== 'ALL' && post.category !== selectedCategory) return false;
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const match =
        post.title.toLowerCase().includes(q) ||
        post.excerpt.toLowerCase().includes(q) ||
        post.tags.some((t) => t.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />

      {/* Hero Header */}
      <section className="bg-gradient-to-r from-[#8B0000] via-[#a00000] to-[#8B0000] text-white py-14 px-4 shadow-md">
        <div className="max-w-7xl mx-auto text-center md:text-left flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 bg-white/20 text-white px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-3">
              <BookOpen className="w-3.5 h-3.5 text-yellow-300" />
              <span>Campus Chronicle & Insights</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
              School Blog & News
            </h1>
            <p className="text-white/85 text-sm sm:text-base max-w-2xl mt-2 leading-relaxed">
              Stay updated with academic achievements, school notifications, co-curricular highlights, and educational insights from Creek View Academy.
            </p>
          </div>

          <Link
            href="/admissions"
            className="bg-white text-[#8B0000] hover:bg-gray-100 font-extrabold px-6 py-3 rounded-full shadow-lg transition text-sm shrink-0 border-2 border-white"
          >
            Admissions 2026-27 Open
          </Link>
        </div>
      </section>

      {/* Filters and Search Bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-8 w-full">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-5 flex flex-col md:flex-row items-center justify-between gap-4 mb-8">
          {/* Categories */}
          <div className="flex flex-wrap gap-2 w-full md:w-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                  selectedCategory === cat
                    ? 'bg-[#8B0000] text-white shadow-md'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {cat === 'ALL' ? 'All Articles' : cat}
              </button>
            ))}
          </div>

          {/* Search bar */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search news, topics..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-gray-50 border border-gray-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
            />
          </div>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPosts.map((post) => (
            <article
              key={post.id}
              onClick={() => setActivePost(post)}
              className="bg-white rounded-3xl shadow-md border border-gray-200 overflow-hidden hover:shadow-xl transition-all cursor-pointer flex flex-col group"
            >
              <div className="relative h-52 w-full overflow-hidden">
                <img
                  src={post.imageUrl}
                  alt={post.title}
                  className="w-full h-full object-cover transition transform group-hover:scale-105 duration-300"
                />
                <span className="absolute top-3 left-3 bg-[#8B0000] text-white text-[11px] font-bold px-3 py-1 rounded-full shadow-md uppercase tracking-wider">
                  {post.category}
                </span>
              </div>

              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-3 text-xs text-gray-500 mb-2">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-[#8B0000]" />
                      {post.date}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-gray-400" />
                      {post.readTime}
                    </span>
                  </div>

                  <h2 className="text-lg font-bold text-gray-900 group-hover:text-[#8B0000] transition leading-snug mb-2.5">
                    {post.title}
                  </h2>

                  <p className="text-gray-600 text-xs sm:text-sm line-clamp-3 leading-relaxed mb-4">
                    {post.excerpt}
                  </p>
                </div>

                <div>
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {post.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-[10px] bg-red-50 text-[#8B0000] px-2 py-0.5 rounded-md font-semibold"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>

                  <div className="pt-3 border-t border-gray-100 flex items-center justify-between text-xs">
                    <span className="font-semibold text-gray-700">By {post.author}</span>
                    <span className="text-[#8B0000] font-bold flex items-center gap-1 group-hover:translate-x-1 transition">
                      Read Article <ChevronRight className="w-4 h-4" />
                    </span>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Article Detail Modal */}
      {activePost && (
        <div
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
          onClick={() => setActivePost(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-3xl w-full my-8 overflow-hidden shadow-2xl border-2 border-red-100 relative"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Image Header */}
            <div className="relative h-64 sm:h-80 w-full">
              <img
                src={activePost.imageUrl}
                alt={activePost.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
              <button
                onClick={() => setActivePost(null)}
                className="absolute top-4 right-4 bg-white/20 hover:bg-white text-white hover:text-black p-2 rounded-full transition"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="absolute bottom-5 left-6 right-6 text-white">
                <span className="bg-[#8B0000] text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-2 inline-block">
                  {activePost.category}
                </span>
                <h2 className="text-xl sm:text-2xl font-black leading-tight text-white drop-shadow">
                  {activePost.title}
                </h2>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-6 sm:p-8 space-y-5">
              <div className="flex flex-wrap items-center justify-between pb-4 border-b border-gray-200 text-xs text-gray-600 gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-red-100 text-[#8B0000] font-bold flex items-center justify-center">
                    {activePost.author.charAt(0)}
                  </div>
                  <div>
                    <span className="font-bold text-gray-900 block">{activePost.author}</span>
                    <span className="text-[11px] text-gray-500">{activePost.role}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span>{activePost.date}</span>
                  <span>•</span>
                  <span>{activePost.readTime}</span>
                </div>
              </div>

              {/* Body paragraphs */}
              <div className="space-y-4 text-gray-700 text-sm sm:text-base leading-relaxed">
                {activePost.content.map((p, idx) => (
                  <p key={idx}>{p}</p>
                ))}
              </div>

              {/* Tags and share */}
              <div className="pt-4 border-t border-gray-200 flex flex-wrap justify-between items-center gap-3">
                <div className="flex flex-wrap gap-1.5">
                  {activePost.tags.map((t) => (
                    <span
                      key={t}
                      className="text-xs bg-red-50 text-[#8B0000] font-bold px-2.5 py-1 rounded-lg"
                    >
                      #{t}
                    </span>
                  ))}
                </div>

                <button
                  onClick={() => setActivePost(null)}
                  className="bg-[#8B0000] text-white text-xs font-bold px-5 py-2.5 rounded-xl hover:bg-red-800 transition"
                >
                  Close Article
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <Footer />
      <BackToTop />
    </div>
  );
}
