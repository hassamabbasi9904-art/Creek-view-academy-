'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import BackToTop from '@/components/BackToTop';
import {
  Upload,
  Calendar,
  BookOpen,
  Image as ImageIcon,
  Trash2,
  CheckCircle,
  AlertCircle,
  LogOut,
  Camera,
  PlusCircle,
  Eye,
  Clock,
  Sparkles,
  RefreshCw,
  X,
  UserCheck,
  Building,
  Edit3,
  MapPin,
  Save,
  User,
  Briefcase
} from 'lucide-react';
import { DiaryEntry } from '@/lib/db';

export default function TeacherDashboardPage() {
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Authenticated teacher state (stored permanently after 1st login)
  const [teacher, setTeacher] = useState<{
    id: string;
    name: string;
    phone: string;
    designation?: string;
    campus?: string;
    subjects?: string[];
    assignedGrades?: string[];
  } | null>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('creek_teacher_data');
      if (stored) {
        try {
          return JSON.parse(stored);
        } catch {
          return null;
        }
      }
    }
    return null;
  });

  const [loading, setLoading] = useState(true);
  const [entries, setEntries] = useState<DiaryEntry[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Form state
  const [campus, setCampus] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('creek_teacher_data');
      if (stored) {
        try {
          const parsed = JSON.parse(stored);
          return parsed.campus || 'Darusslam Campus';
        } catch {
          // ignore
        }
      }
    }
    return 'Darusslam Campus';
  });
  const [grade, setGrade] = useState('Class 9');
  const [section, setSection] = useState('A');
  const [subject, setSubject] = useState('Mathematics');
  const [date, setDate] = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  });
  const [title, setTitle] = useState('');
  const [homeworkText, setHomeworkText] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  // Modal to edit teacher name/designation/campus
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [editName, setEditName] = useState(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('creek_teacher_data');
      if (stored) {
        try {
          return JSON.parse(stored).name || '';
        } catch {
          // ignore
        }
      }
    }
    return '';
  });
  const [editDesignation, setEditDesignation] = useState(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('creek_teacher_data');
      if (stored) {
        try {
          return JSON.parse(stored).designation || '';
        } catch {
          // ignore
        }
      }
    }
    return '';
  });
  const [editCampus, setEditCampus] = useState(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('creek_teacher_data');
      if (stored) {
        try {
          return JSON.parse(stored).campus || 'Darusslam Campus';
        } catch {
          // ignore
        }
      }
    }
    return 'Darusslam Campus';
  });
  const [profileSaving, setProfileSaving] = useState(false);

  // 3-Day active dates choices
  const getAvailableDates = () => {
    const dates = [];
    for (let i = 0; i < 3; i++) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const str = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      const label =
        i === 0
          ? 'Today (' + d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) + ')'
          : i === 1
          ? 'Yesterday (' + d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) + ')'
          : '2 Days Ago (' + d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) + ')';
      dates.push({ value: str, label });
    }
    return dates;
  };
  const availableDates = getAvailableDates();

  const loadTeacherDiaries = async () => {
    try {
      const res = await fetch('/api/diary');
      const data = await res.json();
      if (data.success && data.entries) {
        setEntries(data.entries);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const storedTeacher = localStorage.getItem('creek_teacher_data');
    const token = localStorage.getItem('creek_teacher_token');

    if (!storedTeacher || !token) {
      router.push('/teacher/login');
      return;
    }

    let isMounted = true;
    fetch('/api/diary')
      .then((res) => res.json())
      .then((data) => {
        if (isMounted && data.success && data.entries) {
          setEntries(data.entries);
        }
      })
      .catch((err) => console.error(err))
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('creek_teacher_token');
    localStorage.removeItem('creek_teacher_data');
    router.push('/teacher/login');
  };

  // Image Upload handler (converts file to base64 for instant persistent storage)
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setStatusMsg({ type: 'error', text: 'Image file too large! Please choose an image under 5MB.' });
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Submit Diary with mandatory Campus
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMsg(null);

    if (!campus || !grade || !subject || !homeworkText.trim()) {
      setStatusMsg({ type: 'error', text: 'Please fill in Campus, Grade, Subject, and Homework details.' });
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/diary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          campus,
          grade,
          section,
          subject,
          date,
          title: title.trim() || `${subject} Homework - ${grade}`,
          homeworkText: homeworkText.trim(),
          imageUrl: imagePreview || '',
          teacherName: teacher?.name || 'Faculty Member',
          teacherDesignation: teacher?.designation || '',
          teacherPhone: teacher?.phone || '',
        }),
      });

      const data = await res.json();

      if (data.success) {
        setStatusMsg({
          type: 'success',
          text: `Diary uploaded successfully for ${campus}! Students can now view this in the Daily Diary section.`,
        });
        // Reset inputs
        setTitle('');
        setHomeworkText('');
        setImagePreview(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
        loadTeacherDiaries();
      } else {
        setStatusMsg({ type: 'error', text: data.message || 'Failed to submit diary.' });
      }
    } catch {
      setStatusMsg({ type: 'error', text: 'Server connection error.' });
    } finally {
      setSubmitting(false);
    }
  };

  // Delete Diary item
  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this diary entry?')) return;

    try {
      const res = await fetch(`/api/diary?id=${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        setStatusMsg({ type: 'success', text: 'Entry deleted from database.' });
        loadTeacherDiaries();
      } else {
        setStatusMsg({ type: 'error', text: 'Failed to delete.' });
      }
    } catch {
      setStatusMsg({ type: 'error', text: 'Delete failed.' });
    }
  };

  // Save profile updates to database permanently
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) return;

    setProfileSaving(true);
    try {
      const res = await fetch('/api/auth/teacher', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update-profile',
          phone: teacher?.phone,
          name: editName.trim(),
          designation: editDesignation.trim(),
          campus: editCampus,
        }),
      });
      const data = await res.json();
      if (data.success && data.teacher) {
        setTeacher(data.teacher);
        setCampus(data.teacher.campus || 'Darusslam Campus');
        localStorage.setItem('creek_teacher_data', JSON.stringify(data.teacher));
        if (data.token) {
          localStorage.setItem('creek_teacher_token', data.token);
        }
        setShowProfileModal(false);
        setStatusMsg({ type: 'success', text: 'Teacher Profile updated and permanently saved in database!' });
      }
    } catch {
      setStatusMsg({ type: 'error', text: 'Failed to update profile.' });
    } finally {
      setProfileSaving(false);
    }
  };

  // Helper sample whiteboard images
  const samplePictures = [
    { label: 'Whiteboard Math', url: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?q=80&w=800' },
    { label: 'Science Lab Notes', url: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?q=80&w=800' },
    { label: 'English Notebook', url: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?q=80&w=800' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />

      {/* Top Banner with Teacher Identity */}
      <section className="bg-gradient-to-r from-[#8B0000] via-[#a00000] to-[#8B0000] text-white py-8 px-4 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="inline-flex items-center gap-2 bg-white/20 text-white px-3 py-1 rounded-full text-xs font-bold mb-2">
              <UserCheck className="w-3.5 h-3.5 text-yellow-300" />
              <span>Permanent 1-Time Session Active</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black flex items-center gap-3">
              <span>{teacher?.name || 'Faculty Member'}</span>
              <button
                onClick={() => setShowProfileModal(true)}
                title="Edit Name & Designation"
                className="bg-white/20 hover:bg-white/30 text-white p-1.5 rounded-lg text-xs transition"
              >
                <Edit3 className="w-4 h-4" />
              </button>
            </h1>
            <p className="text-white/90 text-xs sm:text-sm mt-1 flex flex-wrap items-center gap-3">
              <span className="font-semibold bg-white/15 px-2.5 py-0.5 rounded-md">
                Role: {teacher?.designation || 'Subject Teacher'}
              </span>
              <span className="font-semibold bg-white/15 px-2.5 py-0.5 rounded-md flex items-center gap-1">
                <MapPin className="w-3 h-3 text-yellow-300" />
                Campus: {teacher?.campus || 'Darusslam Campus'}
              </span>
              <span className="font-mono text-white/80">
                Mobile: {teacher?.phone}
              </span>
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowProfileModal(true)}
              className="bg-white/15 hover:bg-white/25 text-white font-bold px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition border border-white/20"
            >
              <Edit3 className="w-3.5 h-3.5" />
              Edit Profile
            </button>
            <Link
              href="/diary"
              target="_blank"
              className="bg-yellow-400 hover:bg-yellow-300 text-[#8B0000] font-black px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm"
            >
              <Eye className="w-4 h-4" />
              View Student Diary
            </Link>
            <button
              onClick={handleLogout}
              className="bg-black/30 hover:bg-black/50 text-white font-bold px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition border border-white/20"
            >
              <LogOut className="w-3.5 h-3.5 text-red-300" />
              Sign Out
            </button>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 flex-1 w-full">
        {/* Retention Rule Card */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-8 flex items-start gap-3">
          <Clock className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="text-xs sm:text-sm text-amber-900">
            <span className="font-bold">Active 3-Day Rule & Campus Tracking:</span>
            Jab aap diary post karte hain, to ye selected campus k mutabiq save hoti hai aur active 3 days (Today, Yesterday, 2 days ago) tak school database mein parents aur students ko live nazar aati hai.
          </div>
        </div>

        {/* Status Alert */}
        {statusMsg && (
          <div
            className={`p-4 rounded-2xl mb-8 flex items-start gap-3 border ${
              statusMsg.type === 'success'
                ? 'bg-green-50 border-green-200 text-green-900'
                : 'bg-red-50 border-red-200 text-red-900'
            }`}
          >
            {statusMsg.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            )}
            <p className="text-sm font-semibold">{statusMsg.text}</p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* LEFT: Upload Form */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-3xl shadow-xl border border-gray-200 overflow-hidden">
              <div className="bg-[#8B0000] text-white p-5 flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-base">
                  <PlusCircle className="w-5 h-5 text-yellow-300" />
                  <span>Upload Daily Diary / Homework</span>
                </div>
                <span className="text-xs bg-white/20 px-2.5 py-1 rounded-full font-mono">
                  {date}
                </span>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-5">
                {/* CAMPUS SELECTION (Mandatory) */}
                <div className="bg-red-50/70 p-4 rounded-2xl border border-red-200">
                  <label className="block text-xs font-black text-[#8B0000] uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Building className="w-4 h-4 text-[#8B0000]" />
                    <span>Select Campus for this Diary: *</span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {[
                      { id: 'Darusslam Campus', name: 'Darusslam Campus' },
                      { id: 'Lucknow Campus', name: 'Lucknow Campus' },
                      { id: 'Zaman Town Campus', name: 'Zaman Town Campus' },
                    ].map((camp) => (
                      <button
                        key={camp.id}
                        type="button"
                        onClick={() => setCampus(camp.id)}
                        className={`py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 border ${
                          campus === camp.id
                            ? 'bg-[#8B0000] text-white border-[#8B0000] shadow-sm'
                            : 'bg-white text-gray-700 border-gray-300 hover:border-red-300 hover:bg-red-50/30'
                        }`}
                      >
                        <MapPin className="w-3.5 h-3.5" />
                        <span>{camp.name}</span>
                      </button>
                    ))}
                  </div>
                  <p className="text-[11px] text-gray-500 mt-2">
                    Students search karte waqt isi campus ko select karke yeh diary dekh sakenge.
                  </p>
                </div>

                {/* Date selection (3 days only) */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                    Diary Date (Select Active Day): *
                  </label>
                  <select
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm font-semibold text-gray-900 focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                  >
                    {availableDates.map((d) => (
                      <option key={d.value} value={d.value}>
                        {d.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Grade */}
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Class / Grade: *
                    </label>
                    <select
                      value={grade}
                      onChange={(e) => setGrade(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm font-semibold text-gray-900 focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    >
                      <option value="Pre-Primary">Pre-Primary (Nursery/KG)</option>
                      <option value="Class 1">Class 1</option>
                      <option value="Class 2">Class 2</option>
                      <option value="Class 3">Class 3</option>
                      <option value="Class 4">Class 4</option>
                      <option value="Class 5">Class 5</option>
                      <option value="Class 6">Class 6</option>
                      <option value="Class 7">Class 7</option>
                      <option value="Class 8">Class 8</option>
                      <option value="Class 9">Class 9 (Matric 9th)</option>
                      <option value="Class 10">Class 10 (Matric 10th)</option>
                      <option value="Class 11">Class 11 (First Year)</option>
                      <option value="Class 12">Class 12 (Second Year)</option>
                    </select>
                  </div>

                  {/* Section */}
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Section:
                    </label>
                    <input
                      type="text"
                      value={section}
                      onChange={(e) => setSection(e.target.value)}
                      placeholder="e.g. A, B, Rose, Science"
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm font-semibold text-gray-900 focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Subject */}
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Subject: *
                    </label>
                    <input
                      type="text"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="e.g. Mathematics, Urdu, English"
                      required
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm font-semibold text-gray-900 focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    />
                  </div>

                  {/* Topic / Title */}
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Chapter / Topic Title:
                    </label>
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="e.g. Exercise 4.2 Questions 5-8"
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm font-semibold text-gray-900 focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    />
                  </div>
                </div>

                {/* Homework Description */}
                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                    Written Homework / Tasks / Test Notice: *
                  </label>
                  <textarea
                    rows={4}
                    value={homeworkText}
                    onChange={(e) => setHomeworkText(e.target.value)}
                    placeholder="Write detailed homework instructions here for parents and students (e.g. Solve Q1-Q5 in neat copy, memorize definitions on page 42, test will be taken tomorrow)."
                    required
                    className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-3 text-sm text-gray-900 focus:ring-2 focus:ring-[#8B0000] focus:outline-none leading-relaxed"
                  ></textarea>
                </div>

                {/* Picture Upload (Whiteboard / Notebook Photo) */}
                <div className="border-t border-gray-200 pt-5">
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider">
                      Attach Board or Notebook Photo (Optional):
                    </label>
                    {imagePreview && (
                      <button
                        type="button"
                        onClick={() => setImagePreview(null)}
                        className="text-xs text-red-600 hover:underline flex items-center gap-1 font-semibold"
                      >
                        <X className="w-3.5 h-3.5" />
                        Remove Photo
                      </button>
                    )}
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden"
                  />

                  {imagePreview ? (
                    <div className="relative rounded-2xl overflow-hidden border-2 border-red-300 bg-black/5">
                      <img
                        src={imagePreview}
                        alt="Uploaded preview"
                        className="w-full h-52 object-contain bg-gray-900"
                      />
                      <div className="p-3 bg-white flex justify-between items-center text-xs">
                        <span className="text-green-700 font-bold flex items-center gap-1">
                          <CheckCircle className="w-4 h-4" />
                          Photo attached ready to publish
                        </span>
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="text-[#8B0000] font-bold hover:underline"
                        >
                          Change Photo
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="border-2 border-dashed border-gray-300 hover:border-[#8B0000] rounded-2xl p-6 text-center cursor-pointer bg-gray-50/50 hover:bg-red-50/20 transition group"
                    >
                      <div className="w-12 h-12 bg-red-100 text-[#8B0000] rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition">
                        <Camera className="w-6 h-6" />
                      </div>
                      <p className="text-sm font-bold text-gray-800">
                        Click to take or upload picture from device
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        Upload chalkboard, whiteboard snapshot, or notebook homework sheet (PNG, JPG)
                      </p>
                    </div>
                  )}

                  {!imagePreview && (
                    <div className="mt-3 flex items-center gap-2">
                      <span className="text-[11px] text-gray-500 font-medium">Quick sample photo:</span>
                      {samplePictures.map((sample) => (
                        <button
                          key={sample.label}
                          type="button"
                          onClick={() => setImagePreview(sample.url)}
                          className="text-[11px] bg-gray-100 hover:bg-gray-200 text-gray-700 px-2 py-0.5 rounded-md font-medium transition"
                        >
                          + {sample.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Teacher Info Signature preview */}
                <div className="bg-gray-50 p-3 rounded-xl border border-gray-200 text-xs flex justify-between items-center text-gray-600">
                  <span>Posting As: <strong className="text-gray-900">{teacher?.name || 'Faculty Member'}</strong> ({teacher?.designation || 'Teacher'})</span>
                  <span className="text-[11px] text-gray-500 font-mono">{teacher?.phone}</span>
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-[#8B0000] hover:bg-red-800 text-white font-extrabold py-3.5 rounded-2xl shadow-xl transition flex items-center justify-center gap-2 text-sm disabled:opacity-60"
                >
                  {submitting ? (
                    <span className="inline-flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      Saving to Database...
                    </span>
                  ) : (
                    <>
                      <Upload className="w-4 h-4" />
                      <span>Post Diary to School Database ({campus})</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* RIGHT: Active 3-day Database Records */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white rounded-3xl shadow-xl border border-gray-200 p-6">
              <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-4">
                <div>
                  <h2 className="font-bold text-gray-900 text-base flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-[#8B0000]" />
                    <span>Active 3-Day Diary Records</span>
                  </h2>
                  <p className="text-xs text-gray-500 mt-0.5">
                    All homework currently viewable by parents ({entries.length} items)
                  </p>
                </div>
                <button
                  onClick={loadTeacherDiaries}
                  className="text-xs text-[#8B0000] hover:underline flex items-center gap-1 font-semibold"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Refresh
                </button>
              </div>

              {loading ? (
                <div className="py-12 text-center text-xs text-gray-500">
                  <div className="w-8 h-8 border-2 border-[#8B0000] border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                  Loading database records...
                </div>
              ) : entries.length === 0 ? (
                <div className="py-10 text-center text-gray-500 text-xs">
                  No diary entries found in active 3-day storage.
                </div>
              ) : (
                <div className="space-y-3.5 max-h-[640px] overflow-y-auto pr-1">
                  {entries.map((item) => (
                    <div
                      key={item.id}
                      className="p-3.5 rounded-2xl border border-gray-200 bg-gray-50 hover:bg-white hover:border-red-300 transition"
                    >
                      <div className="flex justify-between items-start gap-2 mb-1.5">
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[10px] font-black bg-[#8B0000] text-white px-2 py-0.5 rounded">
                              {item.grade} {item.section ? `(${item.section})` : ''}
                            </span>
                            <span className="text-xs font-bold text-gray-800">
                              {item.subject}
                            </span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200">
                              🏫 {item.campus || 'Darusslam Campus'}
                            </span>
                          </div>
                          <h4 className="text-xs font-semibold text-gray-900 mt-1 line-clamp-1">
                            {item.title}
                          </h4>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <span className="text-[10px] font-mono bg-gray-200 text-gray-700 px-1.5 py-0.5 rounded">
                            {item.date}
                          </span>
                          <button
                            onClick={() => handleDelete(item.id)}
                            title="Delete Diary"
                            className="text-gray-400 hover:text-red-700 p-1 rounded-md transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <p className="text-xs text-gray-600 line-clamp-2 leading-relaxed bg-white p-2 rounded-lg border border-gray-100">
                        {item.homeworkText}
                      </p>

                      <div className="mt-2 flex items-center justify-between text-[11px] text-gray-500">
                        <span className="text-gray-700 font-medium">
                          By: {item.teacherName} {item.teacherDesignation ? `(${item.teacherDesignation})` : ''}
                        </span>
                        {item.imageUrl && (
                          <span className="text-green-700 font-semibold flex items-center gap-1">
                            <ImageIcon className="w-3 h-3" />
                            Has Photo
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Edit Profile Modal */}
      {showProfileModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-gray-200">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-4">
              <h3 className="font-extrabold text-base text-gray-900 flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-[#8B0000]" />
                <span>Edit Teacher Profile (Saved in Database)</span>
              </h3>
              <button
                onClick={() => setShowProfileModal(false)}
                className="text-gray-400 hover:text-gray-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase mb-1">
                  Teacher Name: *
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  required
                  className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm font-semibold focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase mb-1">
                  Designation / Role: *
                </label>
                <input
                  type="text"
                  value={editDesignation}
                  onChange={(e) => setEditDesignation(e.target.value)}
                  placeholder="e.g. Senior Faculty, Mathematics Incharge"
                  required
                  className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm font-semibold focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase mb-1">
                  Assigned Campus: *
                </label>
                <select
                  value={editCampus}
                  onChange={(e) => setEditCampus(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm font-semibold focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                >
                  <option value="Darusslam Campus">Darusslam Campus</option>
                  <option value="Lucknow Campus">Lucknow Campus</option>
                  <option value="Zaman Town Campus">Zaman Town Campus</option>
                </select>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowProfileModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-gray-300 font-bold text-xs text-gray-700 hover:bg-gray-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={profileSaving}
                  className="flex-1 py-2.5 rounded-xl bg-[#8B0000] hover:bg-red-800 text-white font-extrabold text-xs shadow-md transition flex items-center justify-center gap-1.5"
                >
                  {profileSaving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <Footer />
      <BackToTop />
    </div>
  );
}
