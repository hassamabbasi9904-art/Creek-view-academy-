'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import BackToTop from '@/components/BackToTop';
import {
  Lock,
  Phone,
  KeyRound,
  ShieldCheck,
  ArrowRight,
  CheckCircle,
  AlertCircle,
  UserCheck,
  Sparkles,
  BookOpen,
  School,
  User,
  Briefcase,
  MapPin,
  Check
} from 'lucide-react';

export default function TeacherLoginPage() {
  const router = useRouter();

  // Multi-step form state
  // Step 1: Phone number
  // Step 2: Verification (PIN + Password 'teacher@creek123')
  // Step 3: 1-Time Name & Designation Setup (Only if first-time login)
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [phone, setPhone] = useState('03126172674');
  const [pin, setPin] = useState('');
  const [password, setPassword] = useState('teacher@creek123');
  const [receivedPin, setReceivedPin] = useState<string | null>(null);

  // 1-Time Profile fields
  const [teacherName, setTeacherName] = useState<string>('');
  const [designation, setDesignation] = useState<string>('');
  const [campus, setCampus] = useState<string>('Darusslam Campus');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [alreadyLoggedInTeacher, setAlreadyLoggedInTeacher] = useState<{ name: string; phone: string } | null>(null);

  // Check if teacher is already logged in (Persistent 1-time login)
  useEffect(() => {
    const timer = setTimeout(() => {
      if (typeof window !== 'undefined') {
        const token = localStorage.getItem('creek_teacher_token');
        const stored = localStorage.getItem('creek_teacher_data');
        if (token && stored) {
          try {
            const parsed = JSON.parse(stored);
            setAlreadyLoggedInTeacher(parsed);
          } catch {
            // ignore error
          }
        }
      }
    }, 0);
    return () => clearTimeout(timer);
  }, []);

  // Quick fill helper for 1-click test
  const handleQuickFill = (testPhone: string, testPin: string, testPass: string, name: string, desig: string, camp: string) => {
    setPhone(testPhone);
    setPin(testPin);
    setPassword(testPass);
    setReceivedPin(testPin);
    setTeacherName(name);
    setDesignation(desig);
    setCampus(camp);
    setError(null);
  };

  // Step 1: Request unique PIN for Phone Number
  const handleRequestPin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!phone || phone.trim().length < 8) {
      setError('Please enter a valid Pakistani mobile number (e.g. 03126172674).');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/teacher', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'request-pin', phone: phone.trim() }),
      });
      const data = await res.json();

      if (data.success) {
        setReceivedPin(data.pin);
        setPin(data.pin); // Pre-fill PIN for seamless UX
        if (data.teacherName) setTeacherName(data.teacherName);
        if (data.teacherDesignation) setDesignation(data.teacherDesignation);
        if (data.campus) setCampus(data.campus);

        setSuccessMsg(`Unique PIN for ${phone} is: ${data.pin}. Har teacher ka alag PIN database mein save hai.`);
        setStep(2);
      } else {
        setError(data.message || 'Failed to generate PIN.');
      }
    } catch {
      setError('Connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Step 2: Verify PIN + Password (strictly 'teacher@creek123')
  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!pin || pin.trim().length < 4) {
      setError('Please enter your unique 4-digit verification PIN.');
      return;
    }

    if (!password) {
      setError("Please enter the teacher password: 'teacher@creek123'.");
      return;
    }

    if (password.trim() !== 'teacher@creek123') {
      setError("Ghalat Password! Please enter the authorized password: 'teacher@creek123'");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/teacher', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'verify',
          phone: phone.trim(),
          pin: pin.trim(),
          password: password.trim(),
        }),
      });

      const data = await res.json();

      if (data.success && data.token) {
        // If teacher needs 1-time name & designation setup
        if (data.needsProfileSetup) {
          localStorage.setItem('creek_teacher_token', data.token);
          localStorage.setItem('creek_teacher_data', JSON.stringify(data.teacher));
          setSuccessMsg('Number aur Password verified! Ab apna Name aur Designation sirf 1 bar enter karein.');
          setStep(3);
          return;
        }

        // Already has name and designation! Permanent 1-time login complete
        localStorage.setItem('creek_teacher_token', data.token);
        localStorage.setItem('creek_teacher_data', JSON.stringify(data.teacher));
        setSuccessMsg(`Login kamiyab! Welcome back ${data.teacher.name || 'Teacher'}. Redirecting to Diary Upload Dashboard...`);

        setTimeout(() => {
          router.push('/teacher/dashboard');
        }, 600);
      } else {
        setError(data.message || 'Verification failed. Please check your credentials.');
      }
    } catch {
      setError('Login request failed. Please check network connection.');
    } finally {
      setLoading(false);
    }
  };

  // Step 3: 1-Time Name, Designation & Campus Setup
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!teacherName || !teacherName.trim()) {
      setError('Apna Name enter karein (e.g. Sir Hassam, Miss Farzana).');
      return;
    }

    if (!designation || !designation.trim()) {
      setError('Apna Designation enter karein (e.g. Senior Faculty, Mathematics Teacher).');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/teacher', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update-profile',
          phone: phone.trim(),
          name: teacherName.trim(),
          designation: designation.trim(),
          campus: campus.trim(),
        }),
      });

      const data = await res.json();

      if (data.success && data.teacher) {
        localStorage.setItem('creek_teacher_token', data.token);
        localStorage.setItem('creek_teacher_data', JSON.stringify(data.teacher));
        setSuccessMsg('Name aur Designation database mein permanently save ho gaya! Redirecting to Diary Dashboard...');

        setTimeout(() => {
          router.push('/teacher/dashboard');
        }, 700);
      } else {
        setError(data.message || 'Failed to save profile.');
      }
    } catch {
      setError('Connection error while saving profile.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 py-10 w-full flex items-center justify-center">
        <div className="w-full max-w-xl">
          {/* Active 1-Time Session Notice if already logged in */}
          {alreadyLoggedInTeacher && (
            <div className="bg-emerald-50 border-2 border-emerald-400 rounded-3xl p-5 mb-6 shadow-md flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold">
                  <Check className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="text-sm font-extrabold text-emerald-900">
                    Aap Already Logged In Hain!
                  </h4>
                  <p className="text-xs text-emerald-700">
                    {alreadyLoggedInTeacher.name} ({alreadyLoggedInTeacher.phone})
                  </p>
                </div>
              </div>
              <Link
                href="/teacher/dashboard"
                className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black px-4 py-2.5 rounded-xl shadow transition"
              >
                Go to Dashboard
              </Link>
            </div>
          )}

          {/* Main Card */}
          <div className="bg-white rounded-3xl shadow-2xl border-2 border-red-100 overflow-hidden">
            {/* Top Header */}
            <div className="bg-gradient-to-r from-[#8B0000] to-[#a00000] text-white p-6 sm:p-8 text-center relative">
              <div className="w-16 h-16 bg-white text-[#8B0000] rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg">
                <School className="w-9 h-9" />
              </div>
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
                Teacher Portal Login
              </h1>
              <p className="text-white/85 text-xs sm:text-sm mt-1">
                Sirf 1 bar login karein, phir direct diary upload karein
              </p>

              {/* Progress Steps Indicator */}
              <div className="flex items-center justify-center gap-2 sm:gap-4 mt-6">
                <div
                  className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${
                    step >= 1 ? 'bg-white text-[#8B0000]' : 'bg-white/20 text-white/60'
                  }`}
                >
                  <Phone className="w-3 h-3" />
                  <span>1. Mobile</span>
                </div>
                <div className="w-5 h-0.5 bg-white/30"></div>
                <div
                  className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${
                    step >= 2 ? 'bg-white text-[#8B0000]' : 'bg-white/20 text-white/60'
                  }`}
                >
                  <KeyRound className="w-3 h-3" />
                  <span>2. PIN & Password</span>
                </div>
                <div className="w-5 h-0.5 bg-white/30"></div>
                <div
                  className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold ${
                    step === 3 ? 'bg-white text-[#8B0000]' : 'bg-white/20 text-white/60'
                  }`}
                >
                  <User className="w-3 h-3" />
                  <span>3. Name & Designation</span>
                </div>
              </div>
            </div>

            {/* Form Body */}
            <div className="p-6 sm:p-8">
              {/* Alert Notifications */}
              {error && (
                <div className="bg-red-50 border-l-4 border-red-600 p-4 rounded-xl mb-6 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                  <p className="text-xs sm:text-sm text-red-700 font-semibold">{error}</p>
                </div>
              )}

              {successMsg && (
                <div className="bg-green-50 border-l-4 border-green-600 p-4 rounded-xl mb-6 flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
                  <p className="text-xs sm:text-sm text-green-700 font-semibold">{successMsg}</p>
                </div>
              )}

              {/* STEP 1: Enter Phone Number */}
              {step === 1 && (
                <form onSubmit={handleRequestPin} className="space-y-5">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-2">
                      Teacher Mobile Number:
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-500 font-bold text-sm">
                        🇵🇰 +92
                      </div>
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="03126172674"
                        required
                        className="w-full pl-20 pr-4 py-3 bg-gray-50 border border-gray-300 rounded-xl text-gray-900 font-semibold focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                      />
                    </div>
                    <p className="text-[11px] text-gray-500 mt-1.5">
                      Har teacher ka apna alag PIN system generate aur save karega.
                    </p>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-[#8B0000] hover:bg-red-800 text-white font-extrabold py-3.5 rounded-xl shadow-lg transition flex items-center justify-center gap-2 text-sm disabled:opacity-60"
                  >
                    {loading ? (
                      <span className="inline-flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                        Checking Number...
                      </span>
                    ) : (
                      <>
                        <span>Get Teacher PIN</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </form>
              )}

              {/* STEP 2: Enter Unique PIN + Password (strictly 'teacher@creek123') */}
              {step === 2 && (
                <form onSubmit={handleVerify} className="space-y-5">
                  {/* Phone and Unique PIN Banner */}
                  <div className="bg-red-50 p-3.5 rounded-2xl border border-red-200 text-xs flex justify-between items-center">
                    <div>
                      <span className="text-gray-500 block text-[11px]">Registered Mobile:</span>
                      <span className="font-mono font-bold text-gray-900 text-sm">{phone}</span>
                    </div>
                    {receivedPin && (
                      <div className="text-right">
                        <span className="text-[10px] text-red-600 uppercase font-black tracking-wider block">
                          Aapka Unique PIN:
                        </span>
                        <span className="font-mono text-base font-extrabold text-[#8B0000] bg-white px-2 py-0.5 rounded-md border border-red-200 inline-block">
                          {receivedPin}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* 4-digit PIN */}
                  <div>
                    <div className="flex justify-between items-center mb-1.5">
                      <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider">
                        Enter 4-Digit Teacher PIN:
                      </label>
                      {receivedPin && (
                        <button
                          type="button"
                          onClick={() => setPin(receivedPin)}
                          className="text-[11px] text-[#8B0000] font-bold hover:underline flex items-center gap-1"
                        >
                          <Sparkles className="w-3 h-3" />
                          Auto-fill: {receivedPin}
                        </button>
                      )}
                    </div>

                    <div className="relative">
                      <KeyRound className="w-5 h-5 text-gray-400 absolute left-3.5 top-3.5" />
                      <input
                        type="text"
                        maxLength={6}
                        value={pin}
                        onChange={(e) => setPin(e.target.value)}
                        placeholder="e.g. 4826"
                        required
                        className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-300 rounded-xl text-gray-900 font-mono font-bold text-lg tracking-widest focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Secret Password 'teacher@creek123' */}
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Teacher Password (Must be teacher@creek123):
                    </label>
                    <div className="relative">
                      <Lock className="w-5 h-5 text-gray-400 absolute left-3.5 top-3.5" />
                      <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="teacher@creek123"
                        required
                        className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-300 rounded-xl text-gray-900 font-semibold focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                      />
                    </div>
                    <p className="text-[11px] text-gray-500 mt-1">
                      Sirf <code className="bg-gray-100 text-[#8B0000] font-bold px-1.5 py-0.5 rounded">teacher@creek123</code> daal kar hi login hoga.
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="px-4 py-3 border border-gray-300 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      disabled={loading}
                      className="flex-1 bg-[#8B0000] hover:bg-red-800 text-white font-extrabold py-3.5 rounded-xl shadow-lg transition flex items-center justify-center gap-2 text-sm disabled:opacity-60"
                    >
                      {loading ? (
                        <span className="inline-flex items-center gap-2">
                          <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                          Verifying...
                        </span>
                      ) : (
                        <>
                          <UserCheck className="w-4 h-4" />
                          <span>Verify & Proceed</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}

              {/* STEP 3: 1-Time Name, Designation & Campus Setup */}
              {step === 3 && (
                <form onSubmit={handleSaveProfile} className="space-y-4">
                  <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-xs text-amber-900 mb-2">
                    <span className="font-bold block">1-Time Faculty Profile Setup:</span>
                    Apna Name aur Designation sirf 1 dafa enter karein. Iske baad ye database mein save ho jayega aur bar bar enter nahi karna parega!
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                      Teacher Full Name: *
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
                      <input
                        type="text"
                        value={teacherName}
                        onChange={(e) => setTeacherName(e.target.value)}
                        placeholder="e.g. Sir Hassam, Miss Farzana"
                        required
                        className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-gray-900 font-semibold focus:ring-2 focus:ring-[#8B0000] focus:outline-none text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                      Designation / Role: *
                    </label>
                    <div className="relative">
                      <Briefcase className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
                      <input
                        type="text"
                        value={designation}
                        onChange={(e) => setDesignation(e.target.value)}
                        placeholder="e.g. Senior Faculty, Mathematics Incharge, Vice Principal"
                        required
                        className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-gray-900 font-semibold focus:ring-2 focus:ring-[#8B0000] focus:outline-none text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">
                      Primary Campus: *
                    </label>
                    <div className="relative">
                      <MapPin className="w-4 h-4 text-gray-400 absolute left-3.5 top-3.5" />
                      <select
                        value={campus}
                        onChange={(e) => setCampus(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-300 rounded-xl text-gray-900 font-semibold focus:ring-2 focus:ring-[#8B0000] focus:outline-none text-sm"
                      >
                        <option value="Darusslam Campus">Darusslam Campus</option>
                        <option value="Lucknow Campus">Lucknow Campus</option>
                        <option value="Zaman Town Campus">Zaman Town Campus</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full mt-4 bg-[#8B0000] hover:bg-red-800 text-white font-extrabold py-3.5 rounded-xl shadow-lg transition flex items-center justify-center gap-2 text-sm disabled:opacity-60"
                  >
                    {loading ? (
                      <span className="inline-flex items-center gap-2">
                        <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                        Saving to Database...
                      </span>
                    ) : (
                      <>
                        <ShieldCheck className="w-4 h-4" />
                        <span>Save Profile & Open Diary Dashboard</span>
                      </>
                    )}
                  </button>
                </form>
              )}

              {/* Quick Demo Credentials Panel for immediate testing */}
              <div className="mt-8 pt-6 border-t border-gray-200">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-extrabold text-[#8B0000] uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-yellow-600" />
                    Demo Faculty Accounts (1-Click Test):
                  </span>
                </div>

                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={() =>
                      handleQuickFill(
                        '03126172674',
                        '4826',
                        'teacher@creek123',
                        'Sir Hassam',
                        'Admin & Senior Faculty',
                        'Darusslam Campus'
                      )
                    }
                    className="w-full text-left p-2.5 rounded-xl bg-gray-50 hover:bg-red-50 border border-gray-200 hover:border-red-300 transition text-xs flex justify-between items-center group"
                  >
                    <div>
                      <p className="font-bold text-gray-800 group-hover:text-[#8B0000]">
                        Sir Hassam (Admin & Senior Faculty)
                      </p>
                      <p className="text-gray-500 font-mono text-[11px]">
                        Phone: 03126172674 | Unique PIN: 4826 | Pass: teacher@creek123
                      </p>
                    </div>
                    <span className="text-[11px] font-bold text-[#8B0000] bg-white px-2 py-1 rounded-md shadow-xs border">
                      Fill
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      handleQuickFill(
                        '03001234567',
                        '5914',
                        'teacher@creek123',
                        'Miss Ayesha Khan',
                        'Primary & Middle Wing Incharge',
                        'Lucknow Campus'
                      )
                    }
                    className="w-full text-left p-2.5 rounded-xl bg-gray-50 hover:bg-red-50 border border-gray-200 hover:border-red-300 transition text-xs flex justify-between items-center group"
                  >
                    <div>
                      <p className="font-bold text-gray-800 group-hover:text-[#8B0000]">
                        Miss Ayesha Khan (Primary & Middle Wing)
                      </p>
                      <p className="text-gray-500 font-mono text-[11px]">
                        Phone: 03001234567 | Unique PIN: 5914 | Pass: teacher@creek123
                      </p>
                    </div>
                    <span className="text-[11px] font-bold text-[#8B0000] bg-white px-2 py-1 rounded-md shadow-xs border">
                      Fill
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      handleQuickFill(
                        '03339876543',
                        '3170',
                        'teacher@creek123',
                        'Sir Tariq Mahmood',
                        'Science Faculty Head',
                        'Zaman Town Campus'
                      )
                    }
                    className="w-full text-left p-2.5 rounded-xl bg-gray-50 hover:bg-red-50 border border-gray-200 hover:border-red-300 transition text-xs flex justify-between items-center group"
                  >
                    <div>
                      <p className="font-bold text-gray-800 group-hover:text-[#8B0000]">
                        Sir Tariq Mahmood (Science Faculty Head)
                      </p>
                      <p className="text-gray-500 font-mono text-[11px]">
                        Phone: 03339876543 | Unique PIN: 3170 | Pass: teacher@creek123
                      </p>
                    </div>
                    <span className="text-[11px] font-bold text-[#8B0000] bg-white px-2 py-1 rounded-md shadow-xs border">
                      Fill
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Links below card */}
          <div className="mt-6 text-center text-xs text-gray-600 flex justify-center items-center gap-4">
            <Link href="/diary" className="hover:text-[#8B0000] font-semibold flex items-center gap-1">
              <BookOpen className="w-3.5 h-3.5" />
              View Student Diary
            </Link>
            <span>•</span>
            <Link href="/" className="hover:text-[#8B0000] font-semibold">
              Back to Home
            </Link>
          </div>
        </div>
      </main>

      <Footer />
      <BackToTop />
    </div>
  );
}
