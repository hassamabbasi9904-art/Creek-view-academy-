'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import BackToTop from '@/components/BackToTop';
import {
  GraduationCap,
  Calendar,
  CheckCircle,
  FileText,
  Clock,
  Phone,
  HelpCircle,
  ArrowRight,
  Send,
  MessageCircle,
  School,
  AlertCircle
} from 'lucide-react';

const WHATSAPP_NUMBER = '923126172674';

export default function AdmissionsPage() {
  const [formData, setFormData] = useState({
    student_name: '',
    dob: '',
    gender: 'Male',
    class: 'Class 1 - 5',
    father_name: '',
    mother_name: '',
    mobile: '',
    sibling_student: 'No',
    address: '',
    prev_school: '',
    last_class: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    let message = `*New Admission Enquiry - Creek View Academy*\n\n`;
    message += `*STUDENT NAME*: ${formData.student_name}\n`;
    message += `*DATE OF BIRTH*: ${formData.dob}\n`;
    message += `*GENDER*: ${formData.gender}\n`;
    message += `*APPLYING FOR CLASS*: ${formData.class}\n\n`;
    message += `*FATHER NAME*: ${formData.father_name}\n`;
    message += `*MOTHER NAME*: ${formData.mother_name}\n`;
    message += `*MOBILE NUMBER*: ${formData.mobile}\n`;
    message += `*SIBLING STUDENT*: ${formData.sibling_student}\n`;
    message += `*FULL ADDRESS*: ${formData.address}\n\n`;
    if (formData.prev_school) message += `*PREVIOUS SCHOOL*: ${formData.prev_school}\n`;
    if (formData.last_class) message += `*LAST CLASS PASSED*: ${formData.last_class}\n\n`;
    message += `Regards: Creek View Academy Online Admission Form`;

    const encoded = encodeURIComponent(message);
    const whatsappURL = `https://wa.me/${WHATSAPP_NUMBER}?text=${encoded}`;

    window.open(whatsappURL, '_blank');
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Navbar />

      {/* Hero Header */}
      <section className="bg-gradient-to-r from-[#8B0000] via-[#a00000] to-[#8B0000] text-white py-14 px-4 shadow-md">
        <div className="max-w-7xl mx-auto text-center md:text-left flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 bg-white/20 text-white px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-3">
              <GraduationCap className="w-3.5 h-3.5 text-yellow-300" />
              <span>Session 2026 - 2027</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-black tracking-tight">
              Admission Enquiry Form
            </h1>
            <p className="text-white/85 text-sm sm:text-base max-w-2xl mt-2 leading-relaxed">
              Fill the form below and our admissions team will contact you promptly on WhatsApp with enrollment guidelines, fee details, and assessment schedule.
            </p>
          </div>

          <div className="bg-black/30 backdrop-blur-md p-4 rounded-2xl border border-white/20 text-center shrink-0">
            <span className="text-xs font-bold text-yellow-300 uppercase block">Admissions Helpline</span>
            <span className="text-lg font-black text-white font-mono">+92 312 6172674</span>
          </div>
        </div>
      </section>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-12 flex-1 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* LEFT: Admission Form */}
          <div className="lg:col-span-8 bg-white rounded-3xl shadow-xl border border-gray-200 p-6 sm:p-10">
            <div className="mb-8 pb-4 border-b border-gray-200">
              <h2 className="text-2xl font-black text-gray-900">Online Registration Form</h2>
              <p className="text-xs sm:text-sm text-gray-600 mt-1">
                All starred (*) fields are mandatory. Submitting will prepare your application details directly for our admissions desk.
              </p>
            </div>

            {submitted && (
              <div className="bg-green-50 border-l-4 border-green-600 p-4 rounded-xl mb-8 flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
                <div className="text-xs sm:text-sm text-green-900">
                  <strong className="block">Form Submitted to WhatsApp!</strong>
                  Your enquiry has been dispatched to +92 312 6172674. Please verify the WhatsApp chat window to complete sending.
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* 1. Student Details */}
              <div>
                <h3 className="text-lg font-black text-[#8B0000] mb-4 flex items-center gap-2 pb-2 border-b border-red-100">
                  <span className="w-6 h-6 rounded-full bg-red-100 text-[#8B0000] text-xs font-bold flex items-center justify-center">1</span>
                  <span>Student Details</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Student Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.student_name}
                      onChange={(e) => setFormData({ ...formData, student_name: e.target.value })}
                      placeholder="e.g. Abdullah Khan"
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Date of Birth *
                    </label>
                    <input
                      type="date"
                      required
                      value={formData.dob}
                      onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#8B0000] focus:outline-none font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Gender *
                    </label>
                    <select
                      value={formData.gender}
                      onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#8B0000] focus:outline-none font-medium"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Applying For Class *
                    </label>
                    <select
                      value={formData.class}
                      onChange={(e) => setFormData({ ...formData, class: e.target.value })}
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#8B0000] focus:outline-none font-semibold text-[#8B0000]"
                    >
                      <option value="Pre-Primary (Playgroup / Nursery / KG)">Pre-Primary (Playgroup / Nursery / KG)</option>
                      <option value="Class 1 - 5 (Primary Wing)">Class 1 - 5 (Primary Wing)</option>
                      <option value="Class 6 - 8 (Middle Wing)">Class 6 - 8 (Middle Wing)</option>
                      <option value="Class 9 - 10 (Secondary / Matric)">Class 9 - 10 (Secondary / Matric)</option>
                      <option value="Class 11 - 12 (Intermediate)">Class 11 - 12 (Intermediate)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* 2. Parent/Guardian Details */}
              <div>
                <h3 className="text-lg font-black text-[#8B0000] mb-4 flex items-center gap-2 pb-2 border-b border-red-100">
                  <span className="w-6 h-6 rounded-full bg-red-100 text-[#8B0000] text-xs font-bold flex items-center justify-center">2</span>
                  <span>Parent / Guardian Details</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Father&apos;s Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.father_name}
                      onChange={(e) => setFormData({ ...formData, father_name: e.target.value })}
                      placeholder="Father Name"
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Mother&apos;s Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.mother_name}
                      onChange={(e) => setFormData({ ...formData, mother_name: e.target.value })}
                      placeholder="Mother Name"
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Mobile / WhatsApp Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.mobile}
                      onChange={(e) => setFormData({ ...formData, mobile: e.target.value })}
                      placeholder="0312-XXXXXXX"
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Any Sibling Already Studying in Creek View? *
                    </label>
                    <input
                      type="text"
                      value={formData.sibling_student}
                      onChange={(e) => setFormData({ ...formData, sibling_student: e.target.value })}
                      placeholder="e.g. Yes - Hamza (Class 7) or No"
                      required
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Residential Address (Karachi) *
                    </label>
                    <textarea
                      rows={2}
                      required
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      placeholder="House/Plot No, Street, Society / Area, Karachi"
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    ></textarea>
                  </div>
                </div>
              </div>

              {/* 3. Previous School Details */}
              <div>
                <h3 className="text-lg font-black text-[#8B0000] mb-4 flex items-center gap-2 pb-2 border-b border-red-100">
                  <span className="w-6 h-6 rounded-full bg-red-100 text-[#8B0000] text-xs font-bold flex items-center justify-center">3</span>
                  <span>Previous School Details (If Applicable)</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Previous School Name
                    </label>
                    <input
                      type="text"
                      value={formData.prev_school}
                      onChange={(e) => setFormData({ ...formData, prev_school: e.target.value })}
                      placeholder="School name"
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1.5">
                      Last Class Passed / Percentage
                    </label>
                    <input
                      type="text"
                      value={formData.last_class}
                      onChange={(e) => setFormData({ ...formData, last_class: e.target.value })}
                      placeholder="e.g. Class 4 (A Grade)"
                      className="w-full bg-gray-50 border border-gray-300 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-[#8B0000] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-4 text-center">
                <button
                  type="submit"
                  className="bg-[#8B0000] hover:bg-red-800 text-white font-black text-sm px-10 py-4 rounded-2xl shadow-xl transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-2 mx-auto"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>SEND ADMISSION ENQUIRY TO WHATSAPP</span>
                </button>
                <p className="text-xs text-gray-500 mt-2">
                  Recipient WhatsApp: +92 312 6172674 (Official Creek View Academy Line)
                </p>
              </div>
            </form>
          </div>

          {/* RIGHT: Guidelines and Checklist */}
          <div className="lg:col-span-4 space-y-6">
            {/* Admission Steps */}
            <div className="bg-white rounded-3xl p-6 shadow-md border border-gray-200">
              <h3 className="font-bold text-gray-900 text-base mb-4 flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#8B0000]" />
                <span>Admission Steps</span>
              </h3>
              <ol className="space-y-3 text-xs text-gray-600 list-decimal list-inside font-medium leading-relaxed">
                <li className="pb-2 border-b border-gray-100">
                  <strong>Submit Online Form:</strong> Send your details via WhatsApp or submit in person.
                </li>
                <li className="pb-2 border-b border-gray-100">
                  <strong>Assessment & Interview:</strong> An age-appropriate written screening test & friendly interaction.
                </li>
                <li className="pb-2 border-b border-gray-100">
                  <strong>Document Verification:</strong> Submit birth certificate / B-form, previous report card, and photos.
                </li>
                <li>
                  <strong>Fee Deposit & Enrollment:</strong> Pay the admission dues to confirm student seat.
                </li>
              </ol>
            </div>

            {/* Required Documents */}
            <div className="bg-[#8B0000] text-white rounded-3xl p-6 shadow-xl">
              <h3 className="font-bold text-white text-base mb-3 flex items-center gap-2">
                <FileText className="w-4 h-4 text-yellow-300" />
                <span>Documents Required</span>
              </h3>
              <ul className="space-y-2 text-xs text-white/90">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-300 shrink-0" />
                  <span>Student B-Form / Birth Certificate (NADRA)</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-300 shrink-0" />
                  <span>Father / Guardian CNIC Copy</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-300 shrink-0" />
                  <span>4 Recent Passport Size Photographs</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-300 shrink-0" />
                  <span>Previous School Leaving Certificate (SLC)</span>
                </li>
              </ul>
            </div>

            {/* Need Help Card */}
            <div className="bg-red-50 rounded-3xl p-6 border border-red-200 text-center">
              <h4 className="font-bold text-[#8B0000] text-sm mb-1">Need Admission Assistance?</h4>
              <p className="text-xs text-gray-600 mb-4">
                Call our helpline or visit any of our 3 campuses in Karachi.
              </p>
              <a
                href="tel:+923126172674"
                className="inline-flex items-center gap-2 bg-[#8B0000] text-white font-bold text-xs px-4 py-2.5 rounded-xl hover:bg-red-800 transition"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call +92 312 6172674</span>
              </a>
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <BackToTop />
    </div>
  );
}
