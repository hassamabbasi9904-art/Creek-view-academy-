import { NextRequest, NextResponse } from 'next/server';
import { findTeacherByPhone, saveTeacher, updateTeacherProfile, getDatabase, TeacherUser } from '@/lib/db';

const AUTHORIZED_TEACHER_PASSWORD = 'teacher@creek123';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    // Action 1: Send or generate unique PIN for teacher phone
    if (action === 'request-pin') {
      const { phone } = body;
      if (!phone || phone.trim().length < 8) {
        return NextResponse.json(
          { success: false, message: 'Please enter a valid Pakistani phone number (e.g. 03126172674).' },
          { status: 400 }
        );
      }

      const cleanPhone = phone.replace(/[\s\-\+]/g, '');
      let teacher = findTeacherByPhone(phone);

      const db = getDatabase();
      const existingPins = new Set(db.teachers.map((t) => t.pin));

      let pin = '';
      if (teacher && teacher.pin) {
        pin = teacher.pin;
      } else {
        // Generate a unique 4-digit PIN that is not already used
        let attempts = 0;
        do {
          pin = Math.floor(1000 + Math.random() * 9000).toString();
          attempts++;
        } while (existingPins.has(pin) && attempts < 50);

        if (teacher) {
          teacher.pin = pin;
          saveTeacher(teacher);
        } else {
          const newTeacher: TeacherUser = {
            id: 't-' + Date.now(),
            name: '', // Empty initially so teacher can set name & designation once
            phone: cleanPhone,
            designation: '',
            campus: 'Darusslam Campus',
            pin,
            password: AUTHORIZED_TEACHER_PASSWORD,
            subjects: ['General'],
            assignedGrades: ['All Classes'],
            registeredAt: new Date().toISOString(),
          };
          saveTeacher(newTeacher);
          teacher = newTeacher;
        }
      }

      const isProfileConfigured = Boolean(teacher.name && teacher.name.trim() && teacher.designation && teacher.designation.trim());

      return NextResponse.json({
        success: true,
        message: `Unique verification PIN generated for ${phone}`,
        pin: pin,
        phone: cleanPhone,
        teacherName: teacher.name || '',
        teacherDesignation: teacher.designation || '',
        campus: teacher.campus || 'Darusslam Campus',
        isProfileConfigured,
      });
    }

    // Action 2: Verify Phone + Unique PIN + Password (strictly 'teacher@creek123')
    if (action === 'verify') {
      const { phone, pin, password } = body;

      if (!phone || !pin || !password) {
        return NextResponse.json(
          { success: false, message: 'Phone number, verification PIN, and password are all required.' },
          { status: 400 }
        );
      }

      const teacher = findTeacherByPhone(phone);
      if (!teacher) {
        return NextResponse.json(
          { success: false, message: 'Teacher phone number not found. Please request PIN first.' },
          { status: 404 }
        );
      }

      // 1. Strict Password Verification: MUST be teacher@creek123
      const enteredPassword = password.trim();
      if (enteredPassword !== AUTHORIZED_TEACHER_PASSWORD && enteredPassword !== teacher.password) {
        return NextResponse.json(
          {
            success: false,
            message: `Ghalat Password! Please enter the authorized teacher password '${AUTHORIZED_TEACHER_PASSWORD}'.`,
          },
          { status: 401 }
        );
      }

      // 2. Check Teacher's Unique PIN
      if (teacher.pin !== pin.trim()) {
        return NextResponse.json(
          {
            success: false,
            message: `Ghalat PIN code! Please enter your unique 4-digit PIN code assigned to ${phone}.`,
          },
          { status: 401 }
        );
      }

      // Authenticated! Check if profile needs initial 1-time setup (name & designation)
      const needsProfileSetup = !teacher.name || teacher.name.trim() === '' || !teacher.designation || teacher.designation.trim() === '';

      // Create session token
      const sessionToken = Buffer.from(
        JSON.stringify({
          id: teacher.id,
          name: teacher.name || 'Faculty Member',
          phone: teacher.phone,
          designation: teacher.designation || 'Faculty Member',
          campus: teacher.campus || 'Darusslam Campus',
          exp: Date.now() + 365 * 24 * 60 * 60 * 1000, // 1 year session - teacher only logs in 1 time!
        })
      ).toString('base64');

      return NextResponse.json({
        success: true,
        message: `Authentication successful!`,
        needsProfileSetup,
        teacher: {
          id: teacher.id,
          name: teacher.name || '',
          phone: teacher.phone,
          designation: teacher.designation || '',
          campus: teacher.campus || 'Darusslam Campus',
          subjects: teacher.subjects || [],
          assignedGrades: teacher.assignedGrades || [],
        },
        token: sessionToken,
      });
    }

    // Action 3: Save Teacher Profile (Name, Designation, Campus) - 1-Time Permanent Save
    if (action === 'update-profile') {
      const { phone, name, designation, campus, subjects } = body;

      if (!phone) {
        return NextResponse.json({ success: false, message: 'Phone number is required.' }, { status: 400 });
      }

      if (!name || !name.trim()) {
        return NextResponse.json({ success: false, message: 'Teacher Full Name is required.' }, { status: 400 });
      }

      const updated = updateTeacherProfile(phone, {
        name: name.trim(),
        designation: designation ? designation.trim() : 'Faculty Member',
        campus: campus ? campus.trim() : 'Darusslam Campus',
        subjects: subjects || ['Mathematics', 'Science'],
      });

      if (!updated) {
        return NextResponse.json({ success: false, message: 'Teacher record not found in database.' }, { status: 404 });
      }

      // Create updated token
      const sessionToken = Buffer.from(
        JSON.stringify({
          id: updated.id,
          name: updated.name,
          phone: updated.phone,
          designation: updated.designation,
          campus: updated.campus,
          exp: Date.now() + 365 * 24 * 60 * 60 * 1000,
        })
      ).toString('base64');

      return NextResponse.json({
        success: true,
        message: 'Teacher profile (Name & Designation) saved permanently in database!',
        teacher: {
          id: updated.id,
          name: updated.name,
          phone: updated.phone,
          designation: updated.designation,
          campus: updated.campus,
          subjects: updated.subjects,
          assignedGrades: updated.assignedGrades,
        },
        token: sessionToken,
      });
    }

    // Action 4: Register or verify teacher status
    if (action === 'get-profile') {
      const { phone } = body;
      const teacher = findTeacherByPhone(phone || '');
      if (!teacher) {
        return NextResponse.json({ success: false, message: 'Teacher not found' }, { status: 404 });
      }
      return NextResponse.json({
        success: true,
        teacher: {
          id: teacher.id,
          name: teacher.name,
          phone: teacher.phone,
          designation: teacher.designation,
          campus: teacher.campus,
          pin: teacher.pin,
        },
      });
    }

    return NextResponse.json({ success: false, message: 'Unknown action' }, { status: 400 });
  } catch (error) {
    console.error('Teacher Auth Error:', error);
    return NextResponse.json({ success: false, message: 'Authentication server error' }, { status: 500 });
  }
}
