import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const SYSTEM_INSTRUCTION = `
You are the official AI Assistant & Student Counselor for "Creek View Academy" (Karachi, Pakistan).
Your goal is to answer questions from parents, students, teachers, and visitors warmly, accurately, and concisely.

CRITICAL FIRST-ATTEMPT LANGUAGE DETECTION & RESPONSE RULE:
1. FIRST ATTEMPT DETECTION: On every user message, analyze the language immediately.
2. IF THE USER WRITES IN ENGLISH:
   - You MUST reply 100% in clear, courteous, professional English. Do not mix Urdu.
3. IF THE USER WRITES IN ROMAN URDU (e.g., "kya hal ha", "admissions open hain?", "dairy kahan ha", "fees kitni ha", "campuses kahan hain", "teachers login kaisay karein"):
   - You MUST reply 100% in natural, fluent, friendly Roman Urdu (e.g., "G bilkul! Creek View Academy mein admissions 2026-27 k liye open hain...").
4. If the user writes in Arabic script Urdu, reply in polite Urdu or Roman Urdu.
5. If the user switches languages in subsequent turns, immediately adapt to their latest language.

CREEK VIEW ACADEMY COMPREHENSIVE KNOWLEDGE:
- School Name: Creek View Academy (Karachi, Pakistan)
- Official WhatsApp / Helpline: +92 312 6172674
- Official Email: info@creekviewacademy.edu.pk
- 3 Campuses across Karachi:
  1. Darusslam Campus: Opposite Fazal-e-Elahi Hospital, Darusslam Society, Karachi. (Pre-Primary, Primary & Middle Wing)
  2. Lucknow Campus: Shaq al Mandi Street, Lucknow Society, Karachi. (Primary, Middle & Secondary Wing)
  3. Zaman Town Campus: Zaman Town, Korangi, Karachi. (All Wings, Digital Labs, Science Labs & Library)
- Admissions 2026-27: Currently OPEN for Pre-Primary (Playgroup, Nursery, KG), Primary (Classes 1-5), Middle (Classes 6-8), Secondary / Matric (Classes 9-10 BSEK Board), and Intermediate (Classes 11-12). Parents can fill out the online form on the website (/admissions) which sends the application directly to WhatsApp (+92 312 6172674).
- Daily Student Diary (Roznamcha): Located at /diary. Parents and students can check daily homework, test syllabus, and whiteboard snapshots. Stored on a strict 3-DAY DATABASE RETENTION CYCLE (Today, Yesterday, 2 days ago). Older entries automatically purge so the system remains fresh and fast. Students can filter specifically by their Campus (Darusslam, Lucknow, or Zaman Town), Class, and Subject!
- Teacher Portal: Located at /teacher/login. Teachers sign in with their Phone Number -> 4-digit PIN -> Account Password. After logging in, teachers set/update their Name and Designation (saved permanently in database, never deleted), select their campus, and upload daily diaries with board photos.
- Facilities: Smart digital classrooms, modern physics/chemistry/bio/computer labs, library, co-curricular events.
- School Timings: Monday to Saturday, 8:00 AM - 1:30 PM.

Tone: Professional, welcoming, concise, and helpful. Always provide relevant links or WhatsApp contact (+92 312 6172674) when appropriate.
`;

function getLocalFallback(userMessage: string): string {
  const lower = userMessage.toLowerCase();
  const isRomanUrdu = /\b(kya|kaise|kaisay|hai|hain|kab|kahan|btao|batao|ap|aap|ki|ka|ke|ko|se|mein|me|ho|gaya|kar|karo|acha|shukriya|salam|assalam|chahiye|mil|milega|kitni|fees|dairy|karein|kren)\b/i.test(userMessage);

  if (isRomanUrdu) {
    if (lower.includes('admission') || lower.includes('dakhla')) {
      return 'G bilkul! Creek View Academy mein academic session 2026-27 k new admissions open hain. Aap website par "NEW ADMISSIONS" button click karke online form jama karwa sakte hain, ya direct hamare WhatsApp (+92 312 6172674) par rabta kar sakte hain.';
    }
    if (lower.includes('dairy') || lower.includes('diary') || lower.includes('homework')) {
      return 'Rozana ki school diary (homework) dekhne k liye website par "DAILY DIARY" page visit karein. Wahan aap apna Campus (Darusslam, Lucknow, ya Zaman Town) aur apni Class select karke aakhri 3 din ka homework dekh sakte hain. Purana 3 din se pehle ka data automatic delete ho jata hai.';
    }
    if (lower.includes('campus') || lower.includes('kahan') || lower.includes('address') || lower.includes('branches')) {
      return 'Creek View Academy k Karachi mein 3 main campuses hain:\n1. Darusslam Campus (Opposite Fazal-e-Elahi Hospital, Darusslam Society)\n2. Lucknow Campus (Shaq al Mandi Street, Lucknow Society)\n3. Zaman Town Campus (Zaman Town, Korangi)\nAap kisi bhi campus ka visit subah 8:00 AM se 1:30 PM tak kar sakte hain.';
    }
    if (lower.includes('teacher') || lower.includes('login')) {
      return 'Teachers k liye top header mein "TEACHER LOGIN" ka option mojood hai. Wahan teachers apna mobile number aur PIN enter karke login kar sakte hain aur apna naam, designation aur campus select karke daily diary aur whiteboard pictures upload kar sakte hain.';
    }
    return 'Creek View Academy AI Assistant aap ki khidmat mein hazir hai! Aap admissions, daily student diary, teenon campuses (Darusslam, Lucknow, Zaman Town), ya teacher portal k mutaliq Roman Urdu mein sawal pooch sakte hain. Helpline: +92 312 6172674.';
  } else {
    if (lower.includes('admission') || lower.includes('enroll') || lower.includes('apply')) {
      return 'Admissions for the 2026-27 academic session are currently OPEN at Creek View Academy! You can submit an online application via our Admissions page or contact our admissions desk on WhatsApp at +92 312 6172674.';
    }
    if (lower.includes('diary') || lower.includes('homework')) {
      return 'You can view daily homework on our "DAILY DIARY" page. Filter by your campus (Darusslam, Lucknow, or Zaman Town) and class. Entries are maintained on a strict 3-day active cycle with automatic purging of older records.';
    }
    if (lower.includes('campus') || lower.includes('location') || lower.includes('where')) {
      return 'Creek View Academy operates 3 prime campuses in Karachi:\n1. Darusslam Campus (Opposite Fazal-e-Elahi Hospital, Darusslam Society)\n2. Lucknow Campus (Shaq al Mandi Street, Lucknow Society)\n3. Zaman Town Campus (Zaman Town, Korangi)';
    }
    if (lower.includes('teacher') || lower.includes('portal')) {
      return 'Teachers can securely log in via the "TEACHER LOGIN" button in the top header. Authenticate using your registered phone number, PIN, and password to set your designation and upload daily diary notes and whiteboard photos.';
    }
    return 'Welcome to Creek View Academy! How can I assist you today? You can ask about Admissions 2026-27, Daily Student Diary, Campuses, or Faculty Portal. Feel free to ask in English or Roman Urdu!';
  }
}

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json();

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ success: false, message: 'Messages array is required' }, { status: 400 });
    }

    const lastUserMessage = messages[messages.length - 1]?.content || '';

    // If Gemini API Key is configured, attempt model generation
    if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY') {
      try {
        const contents = messages.map((m: { role: string; content: string }) => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: m.content }],
        }));

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: contents,
          config: {
            systemInstruction: SYSTEM_INSTRUCTION,
            temperature: 0.7,
          },
        });

        const reply = response.text?.trim();
        if (reply) {
          return NextResponse.json({
            success: true,
            reply,
          });
        }
      } catch (geminiError) {
        console.warn('Gemini API call failed, using intelligent local language-detect fallback:', geminiError);
      }
    }

    // Local smart language-detect fallback
    const fallbackReply = getLocalFallback(lastUserMessage);
    return NextResponse.json({
      success: true,
      reply: fallbackReply,
    });
  } catch (error) {
    console.error('Chat API Error:', error);
    return NextResponse.json({
      success: true,
      reply: 'Assalam-o-Alaikum! Creek View Academy administrative desk is available on WhatsApp at +92 312 6172674.',
    });
  }
}
