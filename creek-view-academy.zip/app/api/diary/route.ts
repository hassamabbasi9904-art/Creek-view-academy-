import { NextRequest, NextResponse } from 'next/server';
import { getDiaryEntries, addDiaryEntry, deleteDiaryEntry, purgeOldDiaries, getDatabase } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const campus = searchParams.get('campus');
    const grade = searchParams.get('grade');
    const date = searchParams.get('date');
    const subject = searchParams.get('subject');

    // Always purges old entries automatically
    let entries = getDiaryEntries();

    if (campus && campus !== 'ALL') {
      const c = campus.toLowerCase();
      entries = entries.filter((e) => {
        const itemCamp = (e.campus || '').toLowerCase();
        return itemCamp === c || itemCamp.includes(c) || c.includes(itemCamp);
      });
    }

    if (grade && grade !== 'ALL') {
      entries = entries.filter((e) => e.grade.toLowerCase() === grade.toLowerCase());
    }

    if (date && date !== 'ALL') {
      entries = entries.filter((e) => e.date === date);
    }

    if (subject && subject !== 'ALL') {
      entries = entries.filter((e) => e.subject.toLowerCase() === subject.toLowerCase());
    }

    const db = getDatabase();

    return NextResponse.json({
      success: true,
      count: entries.length,
      entries,
      lastPurgedAt: db.lastPurgedAt,
      retentionNotice: 'Only recent 3 days of homework diaries are stored. Older records are automatically purged.',
    });
  } catch (error) {
    console.error('Error fetching diaries:', error);
    return NextResponse.json({ success: false, message: 'Failed to fetch diaries' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      grade,
      section,
      subject,
      campus,
      teacherName,
      teacherDesignation,
      teacherPhone,
      title,
      homeworkText,
      imageUrl,
      date,
    } = body;

    if (!grade || !subject || !teacherName || !homeworkText) {
      return NextResponse.json(
        { success: false, message: 'Class, Subject, Teacher Name, and Homework text are required.' },
        { status: 400 }
      );
    }

    // Default to today if date not specified
    const targetDate = date || new Date().toISOString().split('T')[0];
    const targetCampus = campus && campus.trim() ? campus.trim() : 'Darusslam Campus';

    const newEntry = addDiaryEntry({
      date: targetDate,
      grade,
      section: section || '',
      subject,
      campus: targetCampus,
      teacherName,
      teacherDesignation: teacherDesignation || '',
      teacherPhone: teacherPhone || '',
      title: title || `${subject} Homework (${grade})`,
      homeworkText,
      imageUrl: imageUrl || '',
    });

    return NextResponse.json({
      success: true,
      message: 'School diary uploaded successfully!',
      entry: newEntry,
    });
  } catch (error) {
    console.error('Error adding diary:', error);
    return NextResponse.json({ success: false, message: 'Failed to post diary entry' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ success: false, message: 'Entry ID is required' }, { status: 400 });
    }

    const deleted = deleteDiaryEntry(id);
    if (!deleted) {
      return NextResponse.json({ success: false, message: 'Entry not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, message: 'Diary entry deleted successfully' });
  } catch (error) {
    console.error('Error deleting diary:', error);
    return NextResponse.json({ success: false, message: 'Failed to delete entry' }, { status: 500 });
  }
}
